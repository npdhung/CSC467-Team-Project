// PURPOSE: allows a new quote to be added to the database

import React from 'react'
import {Link} from 'react-router-dom';         //need to deine this because I am linking editOrder file on this page

class Field extends React.Component {
  constructor(props) {
    super(props);
    //unsure if this next line is necessary or not
    //this.handleSubmit = this.handleSubmit.bind(this);

    //default for customerName is 1 since this is the first value loaded in the <select> list
    //and unless the value is changed to something else and then changed back to 1, 1 cannot be
    //submitted
    this.state = {                                    //defining all state variables 
      apiResponse: "", 
      customers: [] , 
      customerName: "IBM Corporation",
      price: 0.0,
      description: "",
      contact: "",
      quoteID: "",
      itemNumber: "",
      secretNotes: "",
      };
}

//a universal function to handle input through forms
handleChange = (event) => {
  let nam = event.target.name;
  let val = event.target.value;
  this.setState ({[nam]: val});
};

//function to handle sbmitted data
handleSubmit = (event) => {
  event.preventDefault();

  //shows the data on the console on clicking submit button 
  console.log("customer Name: ", this.state.customerName);
  console.log("Price:", this.state.price);
  console.log("Description", this.state.description);
  console.log("Contact:", this.state.contact);
  console.log("quoteID: ", this.state.quoteID);
  console.log("item Number: ", this.state.itemNumber);
  console.log("secret Notes: ", this.state.secretNotes);

  //packages this data and sends it to the backend
  var data = {
    "price": this.state.price,
    "description": this.state.description,
    "quoteID": this.state.quoteID,
    "itemNumber": this.state.itemNumber,
    "customerName": this.state.customerName,
  };

  //shows what data has been send to backend on the console
  console.log(data);

  fetch('http://localhost:5000/post', {
    method: 'POST',
    headers: {
      'Accept': 'application/json',
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(data),
  })
  .then(function (response){
    return response.json();
  })
  .then(function (data){
    console.log(data);
  })
  .catch(function (error){
    console.log(error);
  });

  //an inbuild function to refresh the page on clicking submit
  document.location.reload();

  //this.callAPI("http://localhost:5000/passJSON");

}

callAPI(url) {
  fetch(url)
      .then( res => { 
        //res.text()
        return res.json()
      })
      .then(res => {
        //this.setState({ apiResponse: res })
        this.setState({ customers: res})
      });
}

componentDidMount() {
  //this.callAPI("http://localhost:5000/");
  this.callAPI("http://localhost:5000/passJSON");           //links to the database from where i get the list of customer's in the legacy database
}

  render() {
    return(
      <div>
        <p> Click the link if you want to edit any order </p>                     
        <Link to="/field/editOrder"> Edit</Link>        {/* a link which takes user to editOrder page where the user can insert and edit lineitems table */}
        <center>
        <h1> Insert New Quote/Line Items </h1>
        Customer Name:
        <br/>
        {/* select customer name from the legacy database whose information sales associates wants to enter */}
        {/* it shows the list of all the companies in the drop down menu */}
        <form>
          <select name="customerName" onChange={this.handleChange}>
            {this.state.customers.map(customer =>
              <option value={customer.name} key={customer.id}>
                {customer.name}
              </option>
            )}
          </select>
          {/* forms which ask the sales associates to enter the nesessary information regarding quotes it also enters multiple line items  */}
              <p> Enter Customer E-mail</p>
              <input type="text" name= "contact" value= {this.state.contact } onChange= {this.handleChange} />
              <br />    
              <p> Enter ID of the Quote :</p>
              <input type="text" name= "quoteID" value= {this.state.quoteID} onChange= {this.handleChange} />
              <br />
              <p> Enter the Item Number :</p>
              <input type="text" name= "itemNumber" value= {this.state.itemNumber} onChange= {this.handleChange} />
              <br /> 
              <p> Enter Price of Quote </p>
              < input type="text" name="price" value= {this.state.price} onChange= {this.handleChange} />
              <br />    
              <p> Enter Quote Description:  </p>
              <input type="text" name= "description" value= {this.state.description } onChange= {this.handleChange} />
              <br />
              <p> Secret Notes: </p>
              <input type="text" name= "secretNotes" value= { this.state.secretNotes } onChange= {this.handleChange} />
             <br />
      </form>
      <br/>
      {/* submit the data and invokes handle Submit function  */}
      <button onClick={this.handleSubmit}> Submit </button>
        </center>
      </div>
    ); 
  }

}
export default Field;