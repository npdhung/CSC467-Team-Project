// PURPOSE: This page allows all the links on the various pages to work

import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import { Route, Link, BrowserRouter as Router } from 'react-router-dom';
import App from './App';
//here in index.js we are import all are front-end files and these are the location of all files in these folder
import ProcessingOrder from './ProcessingOrder';
import * as serviceWorker from './serviceWorker';
import Field from './field';
import EditOrder from './editOrder';
import Update from './update';
import Manager from './managers';
import Admin from './admin';
import Internal from './internal';
import AdminSales from './adminSales'
import AdminQuotes from './adminQuotes'
import AdminSalesAdd from './adminSalesAdd'
import Delete from './delete';

//creates routes to each and every file with there component name through which they are accessed 
const routing = (
    <Router>
      <div>
        <Route exact path="/" component={App} />                      
        {/*when we are routing these file we have to use exact path instead of eaxact because 
        there are other files linked to this file the same functionality is been used while routing Admin, managers and internal */}
        <Route exact path="/field" component={Field} />
        <Route path="/field/editOrder" component={EditOrder} />
        <Route path="/field/update" component={Update}/>
        <Route exact path="/managers" component={Manager} /> 
        <Route exact path="/admin" component={Admin} />
        <Route exact path="/admin/sales" component={AdminSales} />
        <Route path="/admin/sales/add" component={AdminSalesAdd} />
        <Route path="/admin/quotes" component={AdminQuotes} />
        <Route exact path="/internal" component={Internal} />
        <Route path="/internal/delete" component={Delete} />
      </div>
    </Router>
  )

  ReactDOM.render(routing, document.getElementById('root'));
//ReactDOM.render(<App />, document.getElementById('root'));
//ReactDOM.render(<ProcessingOrder />, document.getElementById('po'));


// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
serviceWorker.unregister();
