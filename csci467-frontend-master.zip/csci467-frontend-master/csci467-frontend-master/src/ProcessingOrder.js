// Unused at the moment

//import React from 'react';
import React, { Component } from 'react';


class ProcessingOrder extends Component {


    constructor(props) {
      super(props);
      this.state = { orders: {}};
    }

    callAPI(url) {
      fetch(url)
          .then( res => {
            //res.text()
            return res.json()
          })
          .then(res => {
            //this.setState({ apiResponse: res })
            this.setState({ orders: res})
            //console.log("orders:", this.state.orders);
          });
    }
    componentDidMount() {
      this.callAPI("http://localhost:5000/externalPO");
    }

    render() {

        return (
                 <h1> {this.state.orders.name} <br />
                      {this.state.orders.order} <br />
                      {this.state.orders.processDay} <br />

                </h1>
            )
        }



}
export default ProcessingOrder;
