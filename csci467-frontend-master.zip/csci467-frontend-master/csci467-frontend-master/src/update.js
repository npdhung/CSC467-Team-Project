// PURPOSE: Allows a user to update the line items in a quote

import React from 'react'
class Update extends React.Component {
    constructor(props) {
        super(props);
        //unsure if this next line is necessary or not
        //this.handleSubmit = this.handleSubmit.bind(this);
    
        //default for customerName is 1 since this is the first value loaded in the <select> list
        //and unless the value is changed to something else and then changed back to 1, 1 cannot be
        //submitted
        this.state = {                            //defining all our state variables 
          apiResponse: "", 
          customers: [] , 
          updatedPrice: 0.0,
          updatedDescription: "",
          quoteId:"",
          itemNumber:"",
          updateQuote: true,
          };
    }
    
    //a universal function which handles input data through forms
    handleChange = (event) => {
      let nam = event.target.name;
      let val = event.target.value;
      this.setState ({[nam]: val});
    };
    
    //a handle submit button which packes input data and send it to backend 
    handleSubmit = (event) => {
      event.preventDefault();

      //shows the updated price enter on the console
      console.log("Price:", this.state.updatedPrice);
      console.log("Description", this.state.updatedDescription);
    
      //packs the required data and sends it to the backend this data is accessed by req.body.variableName 
      var data = {
        "updatedPrice": this.state.updatedPrice,
        "updatedDescription": this.state.updatedDescription,
        "quoteID": this.state.quoteID,
        "itemNumber": this.state.itemNumber,
        "updateQuote": this.state.updateQuote,
      };
    
      console.log(data);
    
      fetch('http://localhost:5000/post', {
        method: 'POST',
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      })
      .then(function (response){
        return response.json();
      })
      .then(function (data){
        console.log(data);
      })
      .catch(function (error){
        console.log(error);
      });

      //these function is called to refresh the page automatically after the user submits the data
      document.location.reload();
    
      //this.callAPI("http://localhost:5000/passJSON");
    
    }
    
    callAPI(url) {
      fetch(url)
          .then( res => { 
            //res.text()
            return res.json()
          })
          .then(res => {
            //this.setState({ apiResponse: res })
            this.setState({ customers: res})
          });
    }
    
    componentDidMount() {
      //this.callAPI("http://localhost:5000/");
      this.callAPI("http://localhost:5000/passJSON");
    }
    

  render() {
    return (
    <div>
        <center>
    <h1>Update </h1>
    <form>
      {/* these forms takes the input from user and are than accessed using this.state.variableName*/}

            <br /> 
            <p> Enter the Quote ID of the Quote you want to update:</p>
            <input type="text" name="quoteID" value= {this.state.quoteID} onChange= { this.handleChange} />
            <br />
            <p> Enter the Item Number of the Quote you want to update:</p>
            <input type="text" name="itemNumber" value= {this.state.itemNumber} onChange= {this.handleChange} />
            <br />
            <p> Enter Price of Quote </p>
            < input type="text" name="updatedPrice" value= {this.state.updatedPrice} onChange= {this.handleChange} />
            <br />    
            <p> Enter Quote Description:  </p>
            <input type="text" name= "updatedDescription" value= {this.state.updatedDescription } onChange= {this.handleChange} />
            <br />
    </form>
        <br />
        {/* invokes handleSubmit function */}
        <button onClick = {this.handleSubmit}> Update </button>
    </center>
    </div>
    );
  }
}
export default Update;