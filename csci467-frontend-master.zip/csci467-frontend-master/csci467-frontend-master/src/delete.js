// PURPOSE: This page allows users to delete line items from quotes

import React from 'react'

class Delete extends React.Component {
    constructor(props) {
        super(props);
        //unsure if this next line is necessary or not
        //this.handleSubmit = this.handleSubmit.bind(this);
    
        //default for customerName is 1 since this is the first value loaded in the <select> list
        //and unless the value is changed to something else and then changed back to 1, 1 cannot be
        //submitted
        this.state = {                       //state variables
            apiResponse: "",
            lineitems: [] ,
            itemNumber: "",
            quoteId: "",
            deleteQuote: true,            
            };
    }
    //hanldes all form input
    handleChange = (event) => {
      let nam = event.target.name;
      let val = event.target.value;
      this.setState ({[nam]: val});
    };
    
    handleSubmit = (event) => {
      event.preventDefault();
      console.log("itemNumber ", this.state.itemNumber);
      console.log("quoteId:", this.state.quoteId);
    
      //packs this data and sends it to backend
      var data = {
        "deleteQuote": this.state.deleteQuote,
        "itemNumber": this.state.itemNumber,
        "quoteId": this.state.quoteId,
      };
    
      console.log(data);
    
      fetch('http://localhost:5000/post', {
        method: 'POST',
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      })
      .then(function (response){
        return response.json();
      })
      .then(function (data){
        console.log(data);
      })
      .catch(function (error){
        console.log(error);
      });

      document.location.reload();
    
    }
    
    callAPI(url) {
      fetch(url)
          .then( res => { 
            //res.text()
            return res.json()
          })
          .then(res => {
            //this.setState({ apiResponse: res })
            this.setState({ lineitems: res})
          });
    }
    
    componentDidMount() {
      //this.callAPI("http://localhost:5000/");
      this.callAPI("http://localhost:5000/lineitems");
    }

    render() {
        return (
            <div> 
                <center>
        <h1> Delete </h1> 
        {/*print out the lineitems table */}
        <table name="items" onChange={this.handleChange}>
    <tr>
        <th> Quote ID </th>
        <th> Item Number</th>
        <th> Item Price</th>
        <th> Item Description </th>
    </tr>
        {this.state.lineitems.map(items =>
            <tr value = {items.price} key = { items.ItemNumber} >
                <td> {items.QuoteId} </td>
                <td> {items.ItemNumber}</td>
                <td> {items.ItemPrice} </td>
                <td> {items.ItemDescription } </td>  
        </tr>)}
        </table>
        <br /> 
        <br />
        {/*asks the user to enter the quote information to delete the quotes */}
        <form>
            <p> Enter the quote ID of the quote you want to delete</p>
            <input type="text" name="quoteId" value= {this.state.quoteId} onChange= { this.handleChange} />
            <br />
            <br />
            <p> Enter the Item number of the quote you want to delete </p>
            <input type="text" name="itemNumber" value= {this.state.itemNumber} onChange= {this.handleChange} />
            <br />
            <br />
            {/* on clicking this button it invovkes the handleSubmit function which packs the input and sends it to the backend */}
            <button onClick={this.handleSubmit }> Delete </button>
        </form>
        </center>
        </div>

            
            );
    }


};

export default Delete;