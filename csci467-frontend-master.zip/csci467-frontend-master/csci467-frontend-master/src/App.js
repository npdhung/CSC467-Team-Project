// PURPOSE: This page served as a template on which all the rest of the pages of the app were based.
 // It was simply converted to a landing page with links to the other interfaces.

//import React from 'react';
import logo from './logo.svg';
import './App.css';
import React, { Component } from 'react'
import {Link} from 'react-router-dom';

class App extends Component {
  constructor(props) {
    super(props);
    //unsure if this next line is necessary or not
    //this.handleSubmit = this.handleSubmit.bind(this);

    //default for customerName is 1 since this is the first value loaded in the <select> list
    //and unless the value is changed to something else and then changed back to 1, 1 cannot be
    //submitted
    this.state = { apiResponse: "", customers: [] , customerName: "IBM Corporation"};
}

handleChange = (event) => {
  let nam = event.target.name;
  let val = event.target.value;
  this.setState ({[nam]: val});
};

handleSubmit = (event) => {
  event.preventDefault();
  console.log("customerName: ", this.state.customerName);

  var data = {
    "customerName": this.state.customerName,
  };

  console.log(data);

  fetch('http://localhost:5000/post', {
    method: 'POST',
    headers: {
      'Accept': 'application/json',
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(data),
  })
  .then(function (response){
    return response.json();
  })
  .then(function (data){
    console.log(data);
  })
  .catch(function (error){
    console.log(error);
  });

}

callAPI(url) {
    fetch(url)
        .then( res => { 
          //res.text()
          return res.json()
        })
        .then(res => {
          //this.setState({ apiResponse: res })
          this.setState({ customers: res})
        });
}

componentDidMount() {
    //this.callAPI("http://localhost:5000/");
    this.callAPI("http://localhost:5000/passJSON");
}

render() {

  {/* this is the home page of our website where there are links provided to different interfaces 
    and it takes the user to that particular interface where he wants to work on*/}
return(

<div className='App'>
  <h1> Select the Interface you want to work on </h1>
  <Link to="/field"> Field </Link>
  <br />
  <br />
  <Link to="/internal"> Internal </Link>
  <br />
  <br />
  <Link to="/managers"> Managers </Link>
  <br />
  <br />
  <Link to="/admin"> Administrator </Link>

  {/*<p className='App-intro'>{this.state.apiResponse}</p>*/}
    {/*since button is located inside of form, it does not need to be of type "submit" */}
{/*
  <header className='App-header'>
    <img src={logo} className='App-logo' alt='logo'/>
    <h1 className='App-title'> Welcome to React</h1>
  </header>

  Customer Name:
  <br/>
  <form onSubmit={this.handleSubmit}>
    <select name="customerName" onChange={this.handleChange}>
      {this.state.customers.map(customer =>
        <option value={customer.name} key={customer.id}>
          {customer.name}
        </option>
      )}
    </select>

    <br/><button>Submit</button>
  </form>
  <br/> <br/> <br/> <br/>
*/}


  </div>
);

}

}

export default App;
