// Unused at the moment

/*
import React from 'react'

class ManagerEmail extends React.Component {
  
  constructor(props) {
        super(props);
        this.state = { apiResponse: "",emailAddress: ""};
    }
    
    handleChange = (event) => {
      let nam = event.target.name;
      let val = event.target.value;
      this.setState ({[nam]: val});
    };

    handleSubmit = (event) => {
      event.preventDefault();
      console.log("emailAddress: " + this.state.emailAddress)
      alert("Email has been sent to: " + this.state.emailAddress)
    }

    render(){
      return (
        <div>
          <center>
        <h1> Manager's Email Interface </h1>
        <form onSubmit={this.handleSubmit}>
          &nbsp;&nbsp;&nbsp; Enter Customer Email Address: &nbsp;&nbsp;&nbsp;
          <input type="text" name="emailAddress" value={this.state.emailAddress} onChange={this.handleChange}/>&nbsp;&nbsp;&nbsp;
        </form>
        <button onClick={this.handleSubmit}> Send Email </button>
        </center>
        </div>
      )
    }
}
export default ManagerEmail;

*/

