// Unused at the moment

{/*}
import React from 'react'
import {Link} from 'react-router-dom';

class Manager extends React.Component {
    constructor(props) {
        super(props);
        this.state = { backendResponse: [] , finalDiscount: "", Id: ""};
    }
    
    handleChange = (event) => {
      let nam = event.target.name;
      let val = event.target.value;
      this.setState ({[nam]: val});
    };
    
    handleSubmit = (event) => {
      event.preventDefault();
      console.log("finalDiscount: ", this.state.finalDiscount);
      console.log("Quote Id (Hardcoded ATM): ", this.state.Id)
    
      var data = {
        "finalDiscount": this.state.finalDiscount,
        "quoteId": this.state.Id
      };
    
      console.log(data);
    
      fetch('http://localhost:5000/post', {
        method: 'POST',
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      })
      .then(function (response){
        return response.json();
      })
      .then(function (data){
        console.log(data);
      })
      .catch(function (error){
        console.log(error);
      });
    
    }
    
    callAPI(url) {
      fetch(url)
          .then( res => { 
            return res.json()
          })
          .then(res => {
            console.log("This is the back-end's response: ", res)
            this.setState({ backendResponse: res})
          });
    }
    
    componentDidMount() {
            this.callAPI("http://localhost:5000/finalPrice");
    }
    
      render() {
        return(
          <div>
            <h1>Link to Manager Email and Manager PO Interfaces</h1>
            <Link to="/manager/email">Manager's Email Interface</Link>
           <br/>
           <Link to="/manager/PO">Manager's PO Interface</Link>
            <h1> Convert Quote to Purchase Order </h1>
            <br/>
            <form onSubmit={this.handleSubmit}>
              &nbsp;&nbsp; Final Discount: <input type="text"  name="finalDiscount" onChange={this.handleChange}/> &nbsp;
              <button>Enter</button><br/><br/>
            </form>
              <table name="finalAmount"> 
              {this.state.backendResponse.map(display =>
              <tr value={display.finalAmount} key={display.Id}>
              Final Price:
              <td>{display.finalAmount}</td>
              &nbsp;Quote Id (Hardcoded)
              <td>{display.Id}</td>
              </tr>
              )}
              </table>
          </div>
        ); 
      }
}
export default Manager;
*/}
