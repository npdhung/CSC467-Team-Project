// PURPOSE: Allows a user to edit line items

import React from 'react'
import {Link} from 'react-router-dom';
//import {Link} from 'react-router-dom';

class EditOrder extends React.Component {
    constructor(props) {
        super(props);
        //unsure if this next line is necessary or not
        //this.handleSubmit = this.handleSubmit.bind(this);
    
        //default for customerName is 1 since this is the first value loaded in the <select> list
        //and unless the value is changed to something else and then changed back to 1, 1 cannot be
        //submitted
        this.state = { apiResponse: "", lineitems: [] , itemNumber: ""}    //defining state variables
      }
    
      // a universal function which handles the input through forms
    handleChange = (event) => {
      let nam = event.target.name;
      let val = event.target.value;
      this.setState ({[nam]: val});
    };
    
    //this function is invoked once submit button is clicked 
    handleSubmit = (event) => {
      event.preventDefault();
      console.log("itemNumber ", this.state.itemNumber);
    
      //packes this data and sends it to backend 
      var data = {
        "itemNumber": this.state.itemNumber,
        "quoteID": this.state.quoteID,
      };
    
      console.log(data);
    
      fetch('http://localhost:5000/post', {
        method: 'POST',
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      })
      .then(function (response){
        return response.json();
      })
      .then(function (data){
        console.log(data);
      })
      .catch(function (error){
        console.log(error);
      });
    
    }
    
    callAPI(url) {
      fetch(url)
          .then( res => { 
            //res.text()
            return res.json()
          })
          .then(res => {
            //this.setState({ apiResponse: res })
            this.setState({ lineitems: res})
            //console.log(this.state.associates);
          });
    }
    
    componentDidMount() {
      //this.callAPI("http://localhost:5000/");
      this.callAPI("http://localhost:5000/lineitems");                 //links to lineitems table
    }

  render() {
    return (
        <div>
    <h1>Edit Order</h1>

    { /* prints the entire lineitmes table so that the sales associate can update a tuple*/ }
    <table name="items" onChange={this.handleChange}>
    <tr>
        <th> Quote ID </th>
        <th> Item Number</th>
        <th> Item Price</th>
        <th> Item Description </th>
    </tr>
        {this.state.lineitems.map(items =>
            <tr value = {items.price} key = { items.ItemNumber} >
                <td> {items.QuoteId} </td>
                <td> {items.ItemNumber}</td>
                <td> {items.ItemPrice} </td>
                <td> {items.ItemDescription } </td>

              <Link to= "/field/update"> Update </Link>     {/* links to update page*/ }
            </tr>)}

        </table>
        </div>
    );
  }
};
export default EditOrder;