// AUTHOR: Ben Kluga
// PURPOSE: To display sales associate records, and to provide the functionality to edit and delete them

import React from 'react'
import {Link} from 'react-router-dom';

class AdminSales extends React.Component {
    constructor(props) {
        super(props);

    
      // variables:
      // associates: contains the results of the query on the database for all associates with the role
        // of sales
      // associateId: this starts at 1 here, but should actually be intelligently set like in internal.js's
        // callAPI() function
      // showEdit: this variable serves two functions. a sentinel variable used to drop into specific condition
        // in the if/else if statement in the post route on the backend. this variable acts uniquely identifies
        // the function that is making the call. the second function is to conditionally render the "edit associate"
        // portion of the page to keep the page clutter free
      // delete: this is used as another sentinel variable
      // all others: these are used to store user input before it is sent to the database via the backend
        this.state = { 
          associates: [] , 
          associateId: 1,
          showEdit: false,
          FirstName: "",
          LastName: "",
          UserName: "",
          Password: "",
          AccumulatedCommission: "",
          StreetAddress: "",
          City: "",
          State: "",
          Zip: 99999,
          Email: "",
          delete: false,
        };
    }

    // this is part of the conditional rendering portion of the page
    handleClick = () => {
      if (this.state.showEdit == false) {
        this.setState({showEdit: true});
      } else {
        this.setState({showEdit: false});
      }

    }

    // technically "delete" changing between true and false is unnecessary since the backend
      // simply checks if the field exists, not what the value is
    handleOtherClick = (event) => {
      this.setState({delete: true});
    };
    
    handleChange = (event) => {
      let nam = event.target.name;
      let val = event.target.value;
      this.setState ({[nam]: val});
    };
    
    // this is only for the delete functionality
    handleDifferent = (event) => {
      event.preventDefault();

      if (this.state.delete == false) {
        //event.preventDefault();
      } else {

        event.preventDefault();
        console.log("associateID: ", this.state.associateId);

        var data = {
          "associateId": this.state.associateId,
          "delete": this.state.delete,
        };

        fetch('http://localhost:5000/post', {
          method: 'POST',
          headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(data),
        })
        .then(function (response){
          return response.json();
        })
        .then(function (data){
          console.log(data);
        })
        .catch(function (error){
          console.log(error);
        });

        document.location.reload();
      }

      this.setState({delete: false});

    };

    // this is for editing the associate records
    handleSubmit = (event) => {

      event.preventDefault();
      //console.log("editButton: ", this.state.editButton)
      console.log("associateId: ", this.state.associateId);
      console.log("FirstName: ", this.state.FirstName);
      console.log("LastName: ", this.state.LastName);
      console.log("UserName: ", this.state.UserName);
      console.log("Password: ", this.state.Password);
      console.log("Accumulated Commission: ", this.state.AccumulatedCommission);
      console.log("StreetAddress: ", this.state.StreetAddress);
      console.log("City: ", this.state.City);
      console.log("State: ", this.state.State);
      console.log("Zip: ", this.state.Zip);
      console.log("Email: ", this.state.Email);
    
      var data = {
        "showEdit": this.state.showEdit,
        "associateId": this.state.associateId,
        "FirstName": this.state.FirstName,
        "LastName": this.state.LastName,
        "UserName": this.state.UserName,
        "Password": this.state.Password,
        "AccumulatedCommission": this.state.AccumulatedCommission,
        "StreetAddress": this.state.StreetAddress,
        "City": this.state.City,
        "State": this.state.State,
        "Zip": this.state.Zip,
        "Email": this.state.Email,
      };
    
      console.log(data);
    
      fetch('http://localhost:5000/post', {
        method: 'POST',
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      })
      .then(function (response){
        return response.json();
      })
      .then(function (data){
        console.log(data);
      })
      .catch(function (error){
        console.log(error);
      });
    }
    
    callAPI(url) {
      fetch(url)
          .then( res => { 
            return res.json()
          })
          .then(res => {
            this.setState({ associates: res})
            //console.log(this.state.associates);
          });
    }
    
    componentDidMount() {
      this.callAPI("http://localhost:5000/associates");
    }
    
      render() {
        // all of the code from here until return() is the conditional rendering part of the page.
        // variable contains all of the JSX that will be "inserted" into the page if the "Edit" button
        // is clicked
        const isLoggedIn = this.state.showEdit;

        let variable = [
          <form onSubmit={this.handleSubmit}>
          First Name:
          <br/>
          <input type="text" name="FirstName" onChange={this.handleChange}/>
          <br/>
          Last Name:
          <br/>
          <input type="text" name="LastName" onChange={this.handleChange}/>
          <br/>
          Username:
          <br/>
          <input type="text" name="UserName" onChange={this.handleChange}/>
          <br/>
          Password:
          <br/>
          <input type="text" name="Password" onChange={this.handleChange}/>
          <br/>
          Accumulated Commission:
          <br/>
          <input type="text" name="AccumulatedCommission" onChange={this.handleChange}/>
          <br/>
          Street Address:
          <br/>
          <input type="text" name="StreetAddress" onChange={this.handleChange}/>
          <br/>
          City:
          <br/>
          <input type="text" name="City" onChange={this.handleChange}/>
          <br/>
          State:
          <br/>
          <input type="text" name="State" onChange={this.handleChange}/>
          <br/>
          Zip:
          <br/>
          <input type="text" name="Zip" onChange={this.handleChange}/>
          <br/>
          Email:
          <br/>
          <input type="text" name="Email" onChange={this.handleChange}/>
          <br/>
          <button onClick={() => {document.location.reload()}}>Submit</button>
          </form>
        ];
        let toaster;

        // here toaster is set to the value of variable, though "variable" itself could have
          // just been used
        if (isLoggedIn) {
          toaster = (
            variable
            );
        } else {
          toaster = <p></p>;
        }

        return(
          <div>
            <h1> Sales Associate Records </h1>
            <br/>
            <Link to="/admin/">Admin</Link>
            <br/>
            <Link to="/admin/sales/add">Add Sales Associate</Link>
            <br/><br/>
          <table>
                <tr>
                  <th>Name</th>
                  <th>User ID</th>
                  <th>Password</th>
                  <th>Accumulated <br/>Commission</th>
                  <th>Address</th>
                  <th>Email</th>
                </tr>
                {this.state.associates.map(associate =>
                  <tr key={associate.Id}>
                  <td>{associate.LastName}, {associate.FirstName}</td>
                  <td>{associate.UserName}</td>
                  <td>{associate.Password}</td>
                  <td>{associate.AccumulatedCommission}</td>
                  <td>{associate.StreetAddress} {associate.City}, {associate.State} {associate.Zip}</td>
                  <td>{associate.Email}</td>
                  </tr>
                )}
              </table>
          <br/> <br/>
          Associates:
          <form onSubmit={this.handleDifferent}>
              <select name="associateId" onChange={this.handleChange}>
                {this.state.associates.map(associate =>
                  <option value={associate.Id} key={associate.Id}>
                  {associate.LastName}, {associate.FirstName}
                  </option>
                  )}
              </select>
              <button onClick={this.handleClick}>Edit</button>
              <button onClick={this.handleOtherClick}>Delete</button>
            </form>
            {toaster}
          </div>
        ); 
      }
}
export default AdminSales;