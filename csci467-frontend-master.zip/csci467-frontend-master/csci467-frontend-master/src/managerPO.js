// Unused at the moment

/*

import React from 'react'
class ManagerPO extends React.Component {
    constructor(props) {
        super(props);
        //unsure if this next line is necessary or not
        //this.handleSubmit = this.handleSubmit.bind(this);
    
        //default for customerName is 1 since this is the first value loaded in the <select> list
        //and unless the value is changed to something else and then changed back to 1, 1 cannot be
        //submitted
        this.state = { apiResponse: "", prices: [] , finalDiscount: ""};
    }
    
    handleChange = (event) => {
      let nam = event.target.name;
      let val = event.target.value;
      this.setState ({[nam]: val});
    };
    
    handleSubmit = (event) => {
      event.preventDefault();
      console.log("finalDiscount: ", this.state.finalDiscount);

      var data = {
        "finalDiscount": this.state.finalDiscount,
      };
    
      console.log(data);
    
      fetch('http://localhost:5000/post', {
        method: 'POST',
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      })
      .then(function (response){
        return response.json();
      })
      .then(function (data){
        console.log(data);
      })
      .catch(function (error){
        console.log(error);
      });
    
    }
    
    callAPI(url) {
      fetch(url)
          .then( res => { 
            //res.text()
            return res.json()
          })
          .then(res => {
            //this.setState({ apiResponse: res })
            this.setState({ prices: res})
          });
    }
    
    componentDidMount() {
      this.callAPI("http://localhost:5000/finalPrice");
    }
    
      render() {
        return(
          <div>
            <h1> Manager's Purchase Order Interface </h1>
            <br/>
              <form>
              <br/>
              <br/>
              &nbsp;&nbsp;<button>Convert Quote to Purchase Order</button> <br/>
              <br/>
              <table name="poResponse"> 
              <tr>
              <th>Processing Date:</th>
              <th>Sales Commission:</th>
              </tr>
              <tr>
                <td>Example Date</td>
                <td>Example Rate</td>
              </tr>
              </table>
              <br/>
          </form>
          <br/> <br/> <br/> <br/>
          </div>
        ); 
      }
}
export default ManagerPO;

*/
