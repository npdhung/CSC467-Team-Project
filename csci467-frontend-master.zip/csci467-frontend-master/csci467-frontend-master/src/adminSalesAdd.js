// AUTHOR: Ben Kluga
// PURPOSE: To add Sales associates to the database

import React from 'react'
import {Link} from 'react-router-dom';

class AdminSalesAdd extends React.Component {
    constructor(props) {
        super(props);

        // variables:
        // salesAdd: a sentinel variable to differentiate requests on the backend
        // all others: variables to store user input before passing it to the backend
        this.state = { 
            salesAdd: true,
            FirstName: "",
            LastName: "",
            UserName: "",
            Password: "",
            StreetAddress: "",
            City: "",
            State: "",
            Zip: 99999,
            Email: "",
        };
    }
    
    handleChange = (event) => {
      let nam = event.target.name;
      let val = event.target.value;
      this.setState ({[nam]: val});
    };
    
    // prevent default is commented out here so that when the form is submitted, the page automatically
      // reloads
    handleSubmit = (event) => {
      //event.preventDefault();
      console.log("FirstName: ", this.state.FirstName);
      console.log("LastName: ", this.state.LastName);
      console.log("UserName: ", this.state.UserName);
      console.log("Password: ", this.state.Password);
      console.log("StreetAddress: ", this.state.StreetAddress);
      console.log("City: ", this.state.City);
      console.log("State: ", this.state.State);
      console.log("Zip: ", this.state.Zip);
      console.log("Email: ", this.state.Email);
    
      var data = {
        "salesAdd": this.state.salesAdd,
        "FirstName": this.state.FirstName,
        "LastName": this.state.LastName,
        "UserName": this.state.UserName,
        "Password": this.state.Password,
        "StreetAddress": this.state.StreetAddress,
        "City": this.state.City,
        "State": this.state.State,
        "Zip": this.state.Zip,
        "Email": this.state.Email,
      };
    
      console.log(data);
    
      fetch('http://localhost:5000/post', {
        method: 'POST',
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      })
      .then(function (response){
        return response.json();
      })
      .then(function (data){
        console.log(data);
      })
      .catch(function (error){
        console.log(error);
      });
    
    }
  
    
    componentDidMount() {
      // no data needs to be displayed, so no call is made here
    }
    
      render() {
        return(
          <div>
            <Link to="/admin/sales">Sales</Link>
            <h1> Add a Sales Associate </h1>
            <br/>
            <form onSubmit={this.handleSubmit}>
                First Name: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <input type="text" name="FirstName" onChange={this.handleChange}/>
                <br/>
                Last Name: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <input type="text" name="LastName" onChange={this.handleChange}/>
                <br/>
                Username: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <input type="text" name="UserName" onChange={this.handleChange}/>
                <br/>
                Password: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <input type="text" name="Password" onChange={this.handleChange}/>
                <br/>
                Street Address: &nbsp;
                <input type="text" name="StreetAddress" onChange={this.handleChange}/>
                <br/>
                City: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <input type="text" name="City" onChange={this.handleChange}/>
                <br/>
                State: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <input type="text" name="State" onChange={this.handleChange}/>
                <br/>
                Zip: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <input type="text" name="Zip" onChange={this.handleChange}/>
                <br/>
                Email: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <input type="text" name="Email" onChange={this.handleChange}/>
                <br/>
              <br/><button>Submit</button>
          </form>
          <br/> <br/> <br/> <br/>
          </div>
        ); 
      }
}
export default AdminSalesAdd;