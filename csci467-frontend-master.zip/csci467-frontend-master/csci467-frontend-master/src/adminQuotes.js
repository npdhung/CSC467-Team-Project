// AUTHOR: Ben Kluga
// PURPOSE: Allows administrator to search quotes by status, sales associate name, and customer name.
// NOTE: the date range search ability is currently only partially implemented in one of the repositories
  // branches. Perhaps due to the default time that MariaDB tacks onto the DATE column, my query using
  // template literals: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Template_literals
  // doesn't work. Currently, searching for a associate name only works if you search for either a first
  // name or a last name, and not both together. Search queries must exactly match for results to be
  // returned.

import React from 'react'

class AdminQuotes extends React.Component {
    constructor(props) {
        super(props);

        // state variables:
        // customers: contains the customer data from the legacy database
        // searchField: contains the column name in the quote database in which to search.
          // searchField starts with a default value of "Status" because this is the first
          // option given in the select box.
        // searchQuery: contains the value to search for in the database
        // backendResponse: contains the results of the query on the database when the user
          // "searches" in a particular field
        this.state = { 
          customers: {}, 
          searchField: "Status",
          searchQuery: "",
          backendResponse: [],
        };
    }
    
    // handleChange here will handle the changing of the state of any state variable given
      // in the "name" field of a tag to the "value" field that a given "html" tag has. this is
      // accomplished by setting "nam" and "val" equal to event.target.name and event.target.value
      // and supplying "nam" within braces( [nam] ) in the setState function 
    handleChange = (event) => {
      let nam = event.target.name;
      let val = event.target.value;
      this.setState ({[nam]: val});
    };
    

    // handleSubmit handles the event of a user submitting a form with data.
    // this function is asynchronous so that the for loop that exchanges the customer names and IDs
      // has time to run
    handleSubmit = async (event) => {
      //event.preventDefault() prevents the page from reloading every time the submit button is clicked
      event.preventDefault();

      // this for loop converts the string that the user types and compares it to the value of
        // the names in the customers legacy database. if the search query matches, it replaces
        // the string with the customer ID # so that this can be looked up in the database in the
        // quotes table.
      // the setState function must have await called on it so that the function blocks until the
        // for loop is finished running.
      var i;
      for (i = 0; i < this.state.customers.length; i++) {
        if (this.state.customers[i]["name"] == this.state.searchQuery) {
          console.log("name and searchQuery were equal")
          await this.setState({searchQuery: this.state.customers[i]["id"]})
        }
      }

      console.log("searchField: ", this.state.searchField);
      console.log("searchQuery: ", this.state.searchQuery);
    
      // this prepares the data gathered from the user to be sent to the backend
      var data = {
        "searchField": this.state.searchField,
        "searchQuery": this.state.searchQuery,
      };
    
      console.log(data);
    
      // this call sends the data to the backend in a POST request.
      // the JSON format used above must be stringified before it is sent
      fetch('http://localhost:5000/post', {
        method: 'POST',
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      })
      .then(function (response){
        return response.json();
      })
      .then(async (data) => {
        console.log("here is the response from the backend", data);
        
        // the function that executes in this .then block must also be asynchronous so the for loop
          // can finishe running. this for loop grabs the response from the backend and re-exchanges
          // the customer ID for the customer name. the value is updated in temp, and then the state
          // variable backendResponse is updated with temp
        var temp = data;

        var j;
        var k;
        for (j= 0; j < temp.length; j++) {
          for (k=0; k < this.state.customers.length; k++) {
            if (temp[j]["CustomerId"] == this.state.customers[k]["id"]) {
              temp[j]["CustomerId"] = this.state.customers[k]["name"];
              await console.log("temp[j]['CustomerId']", temp[j]["CustomerId"]);
            }
          }
        }

        this.setState({ backendResponse: temp });
        console.log("contents of backendResponse: ", this.state.backendResponse);
      })
      .catch(function (error){
        console.log(error);
      });
    
    }
    
    // this function freshly gets the contents of the legacy database each time the app is started
      // and stores that in the state variable customers
    callAPI(url) {
      fetch(url)
          .then( res => { 
            return res.json()
          })
          .then(res => {
            this.setState({ customers: res})
          });
    }
    
    // the function callAPI is called here when the app runs
    componentDidMount() {
      this.callAPI("http://localhost:5000/passJSON");
    }
    
    // map is a JavaScript function similar to PHP's foreach that allows the contents of a 
      // container to be dynamically "mapped" to html tags. map is used here to display the results
      // of the user's "search" in the database
      render() {
        return(
          <div>
            <h1> Quotes </h1>
            Quotes:
            <br/> <br/>
            <form onSubmit={this.handleSubmit}>
              Search by: &nbsp;
              <select name="searchField" onChange={this.handleChange}>
                <option value="Status">Status</option>
                <option value="ProcessingDate">Date Range</option>
                <option value="Name">Sales Associate</option>
                <option value="customerId">Customer</option>
              </select>
              &nbsp; <input type="text" name="searchQuery" onChange={this.handleChange}></input>
              &nbsp; <button>Search</button>
            </form>
            <br/><br/>
            <table name="" onChange={this.handleChange}>
              <tr>
                <th>Status</th>
                <th>Date</th>
                <th>Sales <br/> Associate</th>
                <th>Customer</th>
              </tr>
              {this.state.backendResponse.map(quote =>
                <tr value={quote.name} key={quote.Id}>
                <td>{quote.Status}</td>
                <td>{quote.ProcessingDate}</td>
                <td>{quote.LastName}, {quote.FirstName}</td>
                <td>{quote.CustomerId}</td>
                </tr>
              )}
            </table>
          <br/> <br/> <br/> <br/>
          </div>
        ); 
      }
}
export default AdminQuotes;