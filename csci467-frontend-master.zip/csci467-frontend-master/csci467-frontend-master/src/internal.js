// PURPOSE: allows associates to enter discounts as either amounts or percentages, as well as providing
  // links to pages where the line items in quotes can be added, edited, or deleted

import React from 'react'
import {Link} from 'react-router-dom';

class Internal extends React.Component {
    constructor(props) {
        super(props);
        this.state = { 
          searchFieldDiscount: "dollarAmount",
          searchQueryDiscount:"",
          finalized: [],
          quoteId: "2",
    }
  }
    
    handleChange = (event) => {
      let nam = event.target.name;
      let val = event.target.value;
      this.setState ({[nam]: val});
    };
    
    handleSubmit = (event) => {
      //event.preventDefault();
      console.log("searchFieldDiscount: ", this.state.searchFieldDiscount);
      console.log("searchQueryDiscount: ",this.state.searchQueryDiscount);
      console.log("quoteId: ", this.state.quoteId);
    
      var data = {
        "searchFieldDiscount": this.state.searchFieldDiscount,
        "searchQueryDiscount": this.state.searchQueryDiscount,
        "quoteId": this.state.quoteId,
      };
    
      console.log("CONSOLE LOGGING: ",data);
    
      fetch('http://localhost:5000/post', {
        method: 'POST',
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      })
      .then(function (response){
        return response.json();
      })
      .then(function (data){
        console.log(data);
      })
      .catch(function (error){
        console.log(error);
      });

    }
    
    callAPI(url) {
      fetch(url)
          .then( res => { 
            return res.json()
          })
          .then(res => {
            //this.setState({ apiResponse: res })
            this.setState({ finalized: res})
            //you don't know what the value of the first quote will be, so change the default value
            //of quoteNumber here after the state of finalized is set
            this.setState({quoteId: this.state.finalized[0]["Id"]})
          });
    }
    
    componentDidMount() {
      //this.callAPI("http://localhost:5000/");
      this.callAPI("http://localhost:5000/finalizedQuotes");
    }
    
      render() {
        return(
          <div>
          <h1> Internal Sales Interface </h1>
          <Link to="/field"> Add or Edit Line Items </Link>
          <br />
          <br />
          <Link to="/internal/delete"> Delete Line Items </Link>
          <br/> <br/>
            <table>
              <tr>
                <th>ID</th>
                <th>Price Before Discount</th>
                <th>Discount Percentage</th>
                <th>Discount Amount</th>
                <th>Subtotal</th>
                <th>Processing Date</th>
                <th>Associate</th>
                <th>Customer</th>
                </tr>
              {this.state.finalized.map(quote =>
              <tr key={quote.Id}>
                <td>{quote.Id}</td>
                <td>{quote.PriceBeforeDiscount}</td>
                <td>{quote.DiscountPercentage}</td>
                <td>{quote.DiscountAmount}</td>
                <td>{quote.Subtotal}</td>
                <td>{quote.ProcessingDate}</td>
                <td>{quote.AssociateId}</td>
                <td>{quote.CustomerId}</td>
              </tr>
              )}
            </table>
            <br/>
            <h3>Add a Discount</h3>
            <form onSubmit={this.handleSubmit}>
              Select Quote ID: &nbsp;
            <select name="quoteId" onChange={this.handleChange}>
                {this.state.finalized.map(quote =>
                  <option value={quote.Id} key={quote.Id}>
                    {quote.Id}
                  </option>
                )}
              </select>
             &nbsp; &nbsp; Enter Discount: &nbsp;
              <select name="searchFieldDiscount" onChange={this.handleChange}>
                <option value="dollarAmount">$ Dollar Amount $</option>
                <option value="percentage">% Percentage %</option>
              </select>
              &nbsp; <input type="text" name="searchQueryDiscount" onChange={this.handleChange}></input>
              &nbsp; <button>Enter</button>
            </form>
            <br/>
            {/*
          <p> Click the link if you want to insert new data or edit the data</p>
          <Link to="/field"> Insert or Edit </Link>
            <br/> <br/> <br/> <br/>     */}
          </div>
        ); 
      }
}

export default Internal;