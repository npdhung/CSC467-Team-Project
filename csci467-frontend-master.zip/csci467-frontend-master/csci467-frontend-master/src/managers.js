//Managers.js Written by Jeff DiTusa
//CSCI467-Project
import React from 'react'
import {Link} from 'react-router-dom'; //Used to link pages

class Manager extends React.Component {
    constructor(props) {
        super(props);
        this.state = {externalPO:{},quotes:[] , quoteId: "1", finalDiscount: "", emailAddress: "",sendPO:true}; //Constructors
    }
    handleChange = (event) => {
      let nam = event.target.name; //Setting the state using the event.target.name
      let val = event.target.value;
      this.setState ({[nam]: val}); //State becomes set here
    };
    
    handleSubmit = (event) => {
      event.preventDefault(); //Prevents the page from refreshing
      console.log("quoteId: ", this.state.quoteId) //Checking values that are set by state
      console.log("finalDiscount: ", this.state.finalDiscount)
    
      //Packaging data to be sent to the backend
      var data = {
        "quoteId": this.state.quoteId, 
        "finalDiscount": this.state.finalDiscount
      };
    
      console.log(data); //Checking to see the data that has been packaged to be sent to the backend
    
      //This fetch function will send the data that has been packaged to the backend to be manipulated accordingly
      fetch('http://localhost:5000/post', {
        method: 'POST',
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      })
      .then(function (response){
        return response.json();
      })
      .then(function (data){
        console.log(data);
      })
      .catch(function (error){
        console.log(error);
      });
    }
    

    handlePoSubmit = (event) => {
      //event.preventDefault();
      console.log("quoteId: ",this.state.quoteId); //Checking values of the state for stuff sent to external PO system
      console.log("sendPO: ", this.state.sendPO);
    
      //The data that is being packaged to be sent to the external PO processing system
      var data = {
        "sendPO": this.state.sendPO, 
        "quoteId": this.state.quoteId,
      };
    
      console.log(data); //Checking the data that will be sent to the external PO processing system
    
      //Function that handles sending the information to the backend that is to be sent to the external PO processing system
      fetch('http://localhost:5000/post', {
        method: 'POST',
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      })
      .then(function (response){
        return response.json();
      })
      .then(function (data){
        console.log(data);
      })
      .catch(function (error){
        console.log(error);
      });
      //document.location.reload(); //Auto refresh
    }

    //This function handles the button click for the email that is to be sent to the customer
    handleEmailSubmit = (event) => {
      event.preventDefault();
      console.log("emailAddress: " + this.state.emailAddress) //Checking the email address that was entered in by the user
      alert("Email has been sent to: " + this.state.emailAddress) //Sending an alert that the email was sent
    }

    //This function works with the componentDidMount function to grab data from a backend route to be stored in state
    callAPI(url) {
      fetch(url)
          .then( res => { 
            return res.json()
          })
          .then(res => {
            this.setState({ quotes: res})
          });
    }

    //This function works with the componentDidMount function to grab data from a backend route to be stored in state
    callExternalPO(url) {
      fetch(url)
          .then( res => { 
            return res.json()
          })
          .then(res => {
            this.setState({externalPO: res})
            console.log(res);
          });
    }
    
    //This function calls the callAPI function and callExternalPO function to pass data from a route on the backend
    componentDidMount() {
      this.callAPI("http://localhost:5000/quotes");
      this.callExternalPO("http://localhost:5000/externalPO");
    }
    
    //The code below is the html for what is shown on the front end page of localhost:3000/managers


      render() {
        return(
          <div>
           <center>
            <h1> Manager's Interface to Convert Quotes to Purchase Orders </h1> 
            </center>
            <br/>
            <form onSubmit={this.handleSubmit}>
                <center>
                    Select a Quote Id: &nbsp;&nbsp;&nbsp; 
            <select name="quoteId" onChange={this.handleChange}>
            {this.state.quotes.map(dropDown =>
              <option value={dropDown.Id} key={dropDown.Id}>
                {dropDown.Id}
              </option>
            )}
            </select>
              &nbsp;&nbsp; Enter Final Discount for the Quote: <input type="text"  name="finalDiscount" onChange={this.handleChange}/> &nbsp;
              <button>Enter</button><br/><br/>
              </center>
            </form>
            {/*}
              <table name="finalAmount"> 
              {this.state.quotes.map(table =>
              <tr key={table.Id}>
              &nbsp;Quote Id:
              <td>{table.Id}</td>
              Final Price:
              <td>{table.FinalPrice}</td>
              </tr>
              )}
              </table>
              */}
              <h2>Purchase Order Processing System </h2>
              <form>
              &nbsp;&nbsp;<button onClick={this.handlePoSubmit}>Convert Quote to Purchase Order</button><br/><br/>
              </form>
              <h3>Commission:</h3>
              &nbsp;&nbsp;{this.state.externalPO["commission"]}
              <br/>
              <h3>Process Day:</h3>
              &nbsp;&nbsp;{this.state.externalPO["processDay"]}
              
              <br/>
              <br/>
              <h2> Manager's Email Interface </h2>
              <form onSubmit={this.handleSubmit}>
               &nbsp;&nbsp;&nbsp; Enter Customer Email Address: &nbsp;&nbsp;&nbsp;
               <input type="text" name="emailAddress" value={this.state.emailAddress} onChange={this.handleChange}/>&nbsp;&nbsp;&nbsp;
               </form>
               <br/>
               &nbsp;&nbsp;<button onClick={this.handleEmailSubmit}> Send Email </button>
               <br/>
               <br/>
               </div>    
        ); 
      }
    }

//Need this statement for the classname
export default Manager;

