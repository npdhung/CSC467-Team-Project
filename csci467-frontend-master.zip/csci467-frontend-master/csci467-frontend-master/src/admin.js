// AUTHOR: Ben Kluga
// PURPOSE: Landing page for the administrative interface.
// This page only contains links to the other administrator pages.

import React from 'react'
import {Link} from 'react-router-dom';

class Admin extends React.Component {
      render() {
        return (
          <div>
          <h1>Admin</h1>
          <Link to="/admin/sales">Sales</Link>
          <br/>
          <Link to="/admin/quotes">Quotes</Link>
          </div>
        ); 
      };
};
export default Admin;