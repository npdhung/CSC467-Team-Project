<?php
       $hostName = "blitz.cs.niu.edu:3306";
        $userName = "student";
        $password = "student";
        $databaseName = "csci467";
        $mysqli = new mysqli($hostName, $userName, $password, $databaseName);
        
        // Check connection
        if ($mysqli->connect_error) {
            die('Connect Error (' .
            $mysqli->connect_errno . ') '.
            $mysqli->connect_error);}
          
         // SQL query to select data from database
            $sql = " SELECT * FROM parts ORDER BY number LIMIT 141 OFFSET 0 ";
            $result = $mysqli->query($sql);
            $mysqli->close();

            $productDesc = array();
            $productPrice = array();
            $loop = 0;
            // LOOP TILL END OF DATA
            while($rows=$result->fetch_assoc())
               {
                 $productPartNo[$loop] = $rows['number'];   
                 $productPict[$loop] = $rows['pictureURL'];
                 $productDesc[$loop] = $rows['description'];
                 $productPrice[$loop] = $rows['price'];
                 $productWeight[$loop] = $rows['weight'];           
                 $loop++; 
                }
                
        $productWeightTotal = 0;
        $cardName = (string) $_POST['cardname'];
        $cardNumber = (string) $_POST['cardnumber'];
        $expMonthYear = (string) $_POST['expmonth'];
        $totalorder  = (float) $_POST['purchaseAmount'];
        $shippingcharge = (float) $_POST['shiptotal'];
        $subtotalcharge = (float) $_POST['subtotal'];
        $taxAmt = (float) $_POST['tax'];
      
        $document_root = $_SERVER['DOCUMENT_ROOT'];    
        $lines= file("$document_root/Auto Parts/database/orders.txt");          
        $number_of_orders = count($lines); 
        $custOrderNumber  = (10001 +  $number_of_orders);
        
        
        
        $authorizationNumber = 0;

        $custfullname = (string) $_POST['fullname'];
        $custemail = (string) $_POST['email'];
        $custaddress = (string) $_POST['address'];
        $custcity = (string) $_POST['city'];
        $custstate = (string) $_POST['state'];
        $custzip = (string) $_POST['zip'];

        date_default_timezone_set('America/Chicago');
        $date = date('m/d/Y h:i:s a', time());

       $url = 'http://blitz.cs.niu.edu/CreditCard/';
        $data = array(
	'vendor' => 'VE005-24',
	'trans' => $custOrderNumber,
	'cc' => $cardNumber,
	'name' => $cardName, 
	'exp' => $expMonthYear, 
	'amount' => $totalorder );

        $options = array(
        'http' => array(
       'header' => array('Content-type: application/json', 'Accept: application/json'),
        'method' => 'POST',
        'content'=> json_encode($data))
        );

        $context  = stream_context_create($options);
        $result2 = file_get_contents($url, false, $context);
        $json = json_decode($result2);
        $authorizationNumber = $json->{'authorization'};          
    
    session_start();   
    $orderQtys = (array) $_SESSION['orderqtys'];
    
    $outputstring2 = "";

?>
<!DOCTYPE html>
<html lang="en">    
    <head>        
        <title>Amplified Auto Parts : Order Confirmation</title>
        <meta charset="utf-8">  
        <meta name="viewport" content="width=device-width initial-scale=1.0">
        <link href="autoparts.css" rel="stylesheet" type="text/css"> 
        
        <style>
			.invoice-box {
				max-width: 800px;
				margin: auto;
				padding: 30px;
				border: 1px solid red;
				box-shadow: 0 0 10px rgba(0, 0, 0, 0.15);
				font-size: 16px;
				line-height: 24px;
				font-family: 'Helvetica Neue', 'Helvetica', Helvetica, Arial, sans-serif;
				color: #555;
			}

			.invoice-box table {
				width: 100%;
				line-height: inherit;
				text-align: left;
			}

			.invoice-box table td {
				padding: 5px;
				vertical-align: top;
			}

			.invoice-box table tr td:nth-child(2) {
				text-align: left;
			}

			.invoice-box table tr.top table td {
				padding-bottom: 20px;
			}

			.invoice-box table tr.top table td.title {
				font-size: 45px;
				line-height: 45px;
				color: #333;
			}

			.invoice-box table tr.information table td {
				padding-bottom: 40px;
                                text-align: left;
			}

			.invoice-box table tr.heading td {
				background: #eee;
				border-bottom: 1px solid #ddd;
				font-weight: bold;
			}

			.invoice-box table tr.details td {
				padding-bottom: 20px;
			}

			.invoice-box table tr.item td {
				border-bottom: 1px solid #eee;
			}

			.invoice-box table tr.item.last td {
				border-bottom: none;
			}

			.invoice-box table tr.total td:nth-child(2) {
				border-top: 2px solid #eee;
				font-weight: bold;
			}

			@media only screen and (max-width: 600px) {
				.invoice-box table tr.top table td {
					width: 100%;
					display: block;
					text-align: center;
				}

				.invoice-box table tr.information table td {
					width: 100%;
					display: block;
					text-align: center;
				}
			}

			/** RTL **/
			.invoice-box.rtl {
				direction: rtl;
				font-family: Tahoma, 'Helvetica Neue', 'Helvetica', Helvetica, Arial, sans-serif;
			}

			.invoice-box.rtl table {
				text-align: right;
			}

			.invoice-box.rtl table tr td:nth-child(2) {
				text-align: left;
			}
		</style>      
</head>
    <body>
        <div id="wrapper">
        
        <header>
            <h1>Amplified Auto Parts</h1>
        </header>
        
        <nav>
            <ul> 
             <li><a href="index.php">Home</a></li>    
            </ul>           
        </nav>
            
             <main>      
                <h1>Amplified Auto Parts</h1>
            
        <?php   if ( $authorizationNumber  > 0){ ?>    
        
            <script language="javascript">  
                   alert('Order Successfully Processed.   Order Number: <?php  echo $custOrderNumber ?>\nAuthorization Number:  <?php  echo $authorizationNumber ?>\nName:  <?php  echo $cardName ?>\nAmount:  <?php  echo "$" .number_format($totalorder, 2)?>\nEmail: <?php echo $custemail ?>');  
                </script> 
           
            <h2>Thanks for your order! We appreciate your business. </h2>            
            <h2> Order Date: <?php  echo $date ?></h2>
               
            <h2>  <?php  echo "$" .number_format($totalorder, 2). " has been successfully charged to your credit card."?></h2>
            <h2> Order Number: <?php  echo $custOrderNumber ?> &nbsp;&nbsp;&nbsp; Authorization Number:  <?php  echo $authorizationNumber ?></h2>   
            <h2>A confirmation email has been sent to  <?php echo $custemail ?></h2> 
                 
                 <?php
                    if(isset($_POST['Yes'])){
                       $custaddress = (string) $_POST['shipaddress'];
                       $custcity = (string) $_POST['shipcity'];
                       $custstate = (string) $_POST['shipstate'];
                       $custzip = (string) $_POST['shipzip'];}
                 ?>
              
            <h2 style="text-align: center">Order Invoice </h2>   
            <div class="invoice-box">
	    <table cellpadding="0" cellspacing="0">
	    <tr class="top">
	    <td colspan="3">
                
	    <table>
	    <tr>
	    <td class="title">
	    <img src="tire.jpg" style="width: 30%; max-width: 80px" /></td>
            <td> <img src="gascap.jpg" style="width: 30%; max-width: 80px" /> </td>  
	    <td style="text-align: right">  Customer Order #:  <?php  echo $custOrderNumber ?><br>Created:  <?php  echo $date ?>
	    </td>
	    </tr>
						
            </table>
	    </td>
	    </tr>

	   <tr class="information">
	   <td colspan="3">
	   <table>
	   <tr>
	   <td>
	   Amplified Auto Parts, Inc.<br />
	   12010 Rustic Trails Road<br />
	   DeKalb, IL 60115 <br />
           service_ampliedautoparts@gmail.com
	  </td>

          <td> <img src="muffler.jpg" style="width: 50%; max-width: 180px" /> </td> 
                                                                
          <td style="text-align: right">
	 <?php echo $custfullname ?><br />
	 <?php echo $custaddress ?><br />
	 <?php echo $custcity ?>,<?php echo $custstate ?>  <?php echo $custzip ?> <br />
         <?php echo $custemail ?>
	 </td>
         </tr>
	 </table>
	 </td>
	 </tr>

	<tr class="heading">
	<td style="text-align: left">Payment Method</td>
        <td></td>
	<td style="text-align: right">Authorization Number </td>
	</tr>

	<tr class="details">
	<td style="text-align: left">Credit card</td>
        <td></td>
	<td style="text-align: right">  <?php  echo $authorizationNumber ?></td>
	</tr>

	<tr class="heading">
	<td style="text-align: left">Quantity</td>
        <td>Item</td>
	<td style="text-align: right">Price</td>
	</tr>

	<?php for($i = 0; $i <= 140; $i++ ){      
        if ($orderQtys[$i] > 0) {
            $productPriceTotal = $productPrice[$i] * $orderQtys[$i];
            $productWeightTotal += ($productWeight[$i] * $orderQtys[$i]);?>   
                  
        <tr class="item">
        <td style="text-align: left;"><?php echo htmlspecialchars($orderQtys[$i])?> </td>
        <td><?php echo htmlspecialchars($productDesc[$i])?> </td>
        <td style="text-align: right;"><?php echo "$".number_format($productPriceTotal, 2) ?></td>
        </tr>  
  
        <?php $outputstring2  .= "^$orderQtys[$i]";  
              $outputstring2  .= "^$productDesc[$i]";}    
        }?>   
				
        <tr class="item">
        <td></td>
	     <td></td>
        <td></td>
	    </tr>
        
        <tr class="item">
        <td></td>
	<td style="text-align: left;"><?php echo "Total Weight: ". htmlspecialchars($productWeightTotal)." lbs."?> </td>                                  
	<td style="text-align: right"><?php  echo "Subotal: $" .number_format($subtotalcharge, 2)?></td>
	</tr>
        
         <tr class="item">
        <td></td>
        <td></td>
	<td style="text-align: right"><?php  echo "Tax: $" .number_format($taxAmt, 2)?></td>
	</tr>
        
         <tr class="item">
        <td></td>
        <td></td>
	<td style="text-align: right"><?php  echo "Shipping: $" .number_format($shippingcharge, 2)?></td>
	</tr>
        
         <tr class="item">
        <td></td>
        <td></td>
	<td style="text-align: right"><?php  echo "Total: $" .number_format($totalorder, 2)?></td>
	</tr>
	</table>
        </div>
	          
            <?php 
               $outputstring = "open"."^".$date."^".$authorizationNumber."^".$custOrderNumber."^".$custfullname."^".$custemail."^".$custaddress."^".$custcity."^".$custstate."^".$custzip."^".$productWeightTotal."^".$shippingcharge. "^".$totalorder."^";
            
               $outputstring2 = substr($outputstring2, 1);
               $outputstring  .= $outputstring2; 
               $outputstring  .= "\n"; 
             
               $fp = fopen("$document_root/Auto Parts/database/orders.txt", 'ab');

               if (!$fp){    
                 echo "<p><strong> There was an internal connection problem.  Please try again later. </strong></p>";
                 exit;       
                }
                flock($fp, LOCK_EX);
               fwrite($fp, $outputstring, strlen($outputstring));
               flock($fp, LOCK_UN);
                fclose($fp);                     
             } 
             else{              
                 echo "<p><strong> Your order cannot be processed at this time. Credit card not authorized. Please try again later. </strong></p>";  
                 } ?>                                  
                 
                 </main> 
            
        <footer>
            
        Copyright &copy; 2022. Amplified Auto Parts, INC. All rights reserved. <br> 
     
        </footer> 
         </div> 
    </body>
</html>