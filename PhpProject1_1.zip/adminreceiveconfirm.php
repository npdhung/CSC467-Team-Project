<?php
             $document_root = $_SERVER['DOCUMENT_ROOT'];          
             $delim = ","; 
             $receiveQuan = $_POST['parts']; 
             $outputqtys = "";            
            $clength2=count($receiveQuan);
               for($x=0;$x<$clength2;$x++){
                 $outputqtys  .= ",$receiveQuan[$x]"; }     
                  $outputqtys = substr($outputqtys, 1);            
               $fp = fopen("$document_root/Auto Parts/database/productonhands.txt", 'w');
              if (!$fp){    
                echo "<p><strong> There was an internal connection problem.  Please try again later. </strong></p>";
                exit;       
               }
                flock($fp, LOCK_EX);
              fwrite($fp, $outputqtys, strlen($outputqtys));
               flock($fp, LOCK_UN);
                fclose($fp);                  
       ?>
<!DOCTYPE html>
<html lang="en">    
    <head>        
        <title>Inventory Confirmation</title>
        <meta charset="utf-8">  
        <meta name="viewport" content="width=device-width initial-scale=1.0">
        <link href="autoparts.css" rel="stylesheet" type="text/css">                  
</head>
    <body>
         <div id="wrapper">    
        <header>
            <h1>Amplified Auto Parts</h1>
        </header>
        
        <nav>
            <ul> 
             <li><a href="index.php">Home</a></li>
            <li><a href="partscatalog.php">Parts Catalog</a></li> 
            </ul>           
        </nav>
    <main>      
                                
       <h2> Inventory quantities have been successfully added and updated. </h2>
           
           <form action="adminreceiving.php" method="post">
             <input type=submit id="btSubmit" value="Continue to Inventory Management Console" style="font-size: 2em;color: red;height:50px;width:75%"> 
                   
       </form>   
     </main> 
            
        <footer>
            
        Copyright &copy; 2022. Amplified Auto Parts, INC. All rights reserved. <br> 
     
        </footer> 
         </div>
    </body>
</html>




