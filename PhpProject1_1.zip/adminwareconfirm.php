<?php

        $hostName = "blitz.cs.niu.edu:3306";
        $userName = "student";
        $password = "student";
        $databaseName = "csci467";
        $mysqli = new mysqli($hostName, $userName, $password, $databaseName);
        
        // Check connection
        if ($mysqli->connect_error) {
            die('Connect Error (' .
            $mysqli->connect_errno . ') '.
            $mysqli->connect_error);}
          
         // SQL query to select data from database
            $sql = " SELECT * FROM parts ORDER BY number LIMIT 141 OFFSET 0 ";
            $result = $mysqli->query($sql);
            $mysqli->close();

            $productDesc = array();
            $productPrice = array();
            $loop = 0;
                // LOOP TILL END OF DATA
                while($rows=$result->fetch_assoc())
                {
                 $productPartNo[$loop] = $rows['number'];   
                 $productPict[$loop] = $rows['pictureURL'];
                 $productDesc[$loop] = $rows['description'];
                 $productPrice[$loop] = $rows['price'];
                 $productWeight[$loop] = $rows['weight'];           
                 $loop++; 
                }           
 
$document_root = $_SERVER['DOCUMENT_ROOT'];
date_default_timezone_set('America/Chicago');
$date = date('m/d/Y h:i:s a', time());
$tomorrow = date("m/d/Y", strtotime("+1 day"));      

       $custOrderNumber  = (float) $_POST['ordernumber'];
       $shippingcharge = (float) $_POST['shipnumber'];
       $authorizationNumber = (float) $_POST['authnumber'];
       $datecreate = (string) $_POST['datenumber'];   
       $totalorder  = (float) $_POST['amtnumber'];
       $productWeightTotal = (float) $_POST['shipwt'];
       $reference = (float) $_POST['refno'];       
        $custfullname = (string) $_POST['namenumber'];
        $custemail = (string) $_POST['emailnumber'];
        $custaddress = (string) $_POST['addressnumber'];
        $custcity = (string) $_POST['citynumber'];
        $custstate = (string) $_POST['statenumber'];
        $custzip = (string) $_POST['zipnumber'];   
        $reference-=1;
        $passed_array = (array) unserialize(base64_decode($_POST["orderproducts"]));
        $subtotalcharge = 0;
        $productPriceTotal = 0;    
        $pieces = explode("^", $passed_array[$reference]);
      
        $productOH = array ();  
        $delim = ","; 
        $status= file("$document_root/Auto Parts/database/productonhands.txt");
       $k = 0;
       $lines = explode($delim, $status[$k]);
       foreach ($lines as $val) {  
       $productOH[$k] = $val; 
       $k++;}         
        
?>

<!DOCTYPE html>
<html lang="en">    
    <head>        
        <title>Order Fulfillment</title>
        <meta charset="utf-8">  
        <meta name="viewport" content="width=device-width initial-scale=1.0">
        <link href="autoparts.css" rel="stylesheet" type="text/css"> 
         <script src="alert/dist/alertify.min.js"></script>
	<link rel="stylesheet" href="alert/dist/alertify.core.css" />
	<link rel="stylesheet" href="alert/dist/alertify.default.css" id="toggleCSS" />
        
         <style>
* {box-sizing: border-box;}

#myInput {
  background-image: url('/css/searchicon.png');
  background-position: 10px 10px;
  float: right;
  background-repeat: no-repeat;
  width: 20%;
  font-size: 16px;
  padding: 12px 20px 12px 40px;
  border: 1px solid #ddd;
  margin-bottom: 12px;
}

label {
  width:150px;
  display: inline-block;
}
button{
 margin-left: 210px;}


			.invoice-box {
				max-width: 800px;
				margin: auto;
				padding: 30px;
				border: 1px solid red;
				box-shadow: 0 0 10px rgba(0, 0, 0, 0.15);
				font-size: 16px;
				line-height: 24px;
				font-family: 'Helvetica Neue', 'Helvetica', Helvetica, Arial, sans-serif;
				color: #555;
			}

			.invoice-box table {
				width: 100%;
				line-height: inherit;
				text-align: left;
			}

			.invoice-box table td {
				padding: 5px;
				vertical-align: top;
			}

			.invoice-box table tr td:nth-child(2) {
				text-align: left;
			}

			.invoice-box table tr.top table td {
				padding-bottom: 20px;
			}

			.invoice-box table tr.top table td.title {
				font-size: 45px;
				line-height: 45px;
				color: #333;
			}

			.invoice-box table tr.information table td {
				padding-bottom: 40px;
                                text-align: left;
			}

			.invoice-box table tr.heading td {
				background: #eee;
				border-bottom: 1px solid #ddd;
				font-weight: bold;
			}

			.invoice-box table tr.details td {
				padding-bottom: 20px;
			}

			.invoice-box table tr.item td {
				border-bottom: 1px solid #eee;
			}

			.invoice-box table tr.item.last td {
				border-bottom: none;
			}

			.invoice-box table tr.total td:nth-child(2) {
				border-top: 2px solid #eee;
				font-weight: bold;
			}

			@media only screen and (max-width: 600px) {
				.invoice-box table tr.top table td {
					width: 100%;
					display: block;
					text-align: center;
				}

				.invoice-box table tr.information table td {
					width: 100%;
					display: block;
					text-align: center;
				}
			}

			/** RTL **/
			.invoice-box.rtl {
				direction: rtl;
				font-family: Tahoma, 'Helvetica Neue', 'Helvetica', Helvetica, Arial, sans-serif;
			}

			.invoice-box.rtl table {
				text-align: right;
			}

			.invoice-box.rtl table tr td:nth-child(2) {
				text-align: left;
			}
                        
                        
         .buttons {
width: 200px;
margin: 0 auto;
display: inline;}

    .action_btn {
width: 200px;
margin: 0 auto;
display: inline;}    
    
    
    
    
    
    
    
    
		</style>      

</head>
    <body>
         <div id="wrapper">    
        <header>
            <h1>Amplified Auto Parts</h1>
        </header>      
        <nav>
            <ul> 
              <li><a href="adminmenu.php">Company Portal Main Menu</a></li>
              <li><a href="adminreceiving.php">Receiving Console</a></li>        
            </ul>           
        </nav>
    <main>  
         <form action="adminwaresubmit.php" method="post"> 
             
    <h3 style="text-align: center">Complete Order  <?php echo $date?></h3>  
      
    
     <h2 style="text-align: center">Order Invoice </h2>   
            <div class="invoice-box">
	    <table cellpadding="0" cellspacing="0">
	    <tr class="top">
	    <td colspan="3">
                
	    <table>
	    <tr>
	    <td class="title">
	    <img src="tire.jpg" style="width: 30%; max-width: 80px" /></td>
            <td> <img src="gascap.jpg" style="width: 30%; max-width: 80px" /> </td>  
	    <td style="text-align: right">  Customer Order #:  <?php  echo $custOrderNumber ?><br>Created:  <?php  echo $datecreate ?>
	    </td>
	    </tr>
						
            </table>
	    </td>
	    </tr>

	   <tr class="information">
	   <td colspan="3">
	   <table>
	   <tr>
	   <td>
	   Amplified Auto Parts, Inc.<br />
	   12010 Rustic Trails Road<br />
	   DeKalb, IL 60115 <br />
           service_ampliedautoparts@gmail.com
	  </td>

          <td> <img src="muffler.jpg" style="width: 50%; max-width: 180px" /> </td> 
                                                                
          <td style="text-align: right">
	 <?php echo $custfullname ?><br />
	 <?php echo $custaddress ?><br />
	 <?php echo $custcity ?>,<?php echo $custstate ?>  <?php echo $custzip ?> <br />
         <?php echo $custemail ?>
	 </td>
         </tr>
	 </table>
	 </td>
	 </tr>

	<tr class="heading">
	<td style="text-align: left">Payment Method</td>
        <td></td>
	<td style="text-align: right">Authorization Number </td>
	</tr>

	<tr class="details">
	<td style="text-align: left">Credit card</td>
        <td></td>
	<td style="text-align: right">  <?php  echo $authorizationNumber ?></td>
	</tr>

	<tr class="heading">
	<td style="text-align: left">Quantity</td>
        <td>Item</td>
	<td style="text-align: right">Price</td>
	</tr> 
                  
        <?php 
         $e = 0; 
         foreach ($pieces as $data) {$e++;}
         for($i = 0; $i < $e-1; $i++ ){?>                        
        <tr class="item">
        <td style="text-align: left;"><?php echo $pieces[$i] ?> </td>
         <?php $i++; ?> 
        <td><?php echo $pieces[$i]?> </td>
        
        <?php 
        $pieces[$i]= trim($pieces[$i]);
        for($j = 0; $j <= 140; $j++ ){      
        if ($productDesc[$j] ==  $pieces[$i]) {
        $productPriceTotal = $productPrice[$j] * $pieces[$i-1];
        $productOH[$j] = $productOH[$j] - $pieces[$i-1];
        }}
            
        $subtotalcharge += $productPriceTotal;?>   
            
        <td style="text-align: right;"><?php echo "$".number_format($productPriceTotal, 2) ?></td>
        </tr>  
        <?php  }
        
        $taxrate = 0.0885;
        $tax = ($subtotalcharge * $taxrate);
        
              $delime = ","; 
             $outputqtys = "";            
            $clength2=count($productOH);
               for($x=0;$x<$clength2;$x++){
                 $outputqtys  .= ",$productOH[$x]"; }     
                  $outputqtys = substr($outputqtys, 1);            
               $fp2 = fopen("$document_root/Auto Parts/database/productonhands.txt", 'w');
              if (!$fp2){    
                echo "<p><strong> There was an internal connection problem.  Please try again later. </strong></p>";
                exit;       
               }
                flock($fp2, LOCK_EX);
              fwrite($fp2, $outputqtys, strlen($outputqtys));
               flock($fp2, LOCK_UN);
                fclose($fp2);             
        
       ?>   
          			
        <tr class="item">
        <td></td>
	<td></td>
        <td></td>
	</tr>
        
        <tr class="item">
        <td></td>
	<td style="text-align: left;"><?php echo "Total Weight: ". htmlspecialchars($productWeightTotal)." lbs."?> </td>                                  
	<td style="text-align: right"><?php  echo "Subotal: $" .number_format($subtotalcharge, 2)?></td>
	</tr>
             
          <tr class="item">
        <td></td>
        <td></td>
	<td style="text-align: right"><?php  echo "Tax: $" .number_format($tax, 2)?></td>
	</tr>
        
         <tr class="item">
        <td></td>
        <td></td>
	<td style="text-align: right"><?php  echo "Shipping: $" .number_format($shippingcharge, 2)?></td>
	</tr>
        
         <tr class="item">
        <td></td>
        <td></td>
	<td style="text-align: right"><?php  echo "Total: $" .number_format($totalorder, 2)?></td>
	</tr>
        
	</table>
        </div>
     <br><br>
     <h2 style="text-align: left">Packing Slip </h2>  
<table cellspacing=0 cellpadding="2" border=0 style="width:8in">
    <thead>
      <tr>
        <th colspan="2">
          Packing Slip
        </th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td colspan="2" style="width:4.5in" class="store-info">
          <div class="company-name"> Amplified Auto Parts, Inc</div>
          <div>12010 Rustic Trails Road.<br/> DeKalb, IL 60115</div>
        </td>
        <td style="width:3.5in;" align="right" valign="top">

        </td>
      </tr>
      <tr>
        <td style="height:0.15in"></td>
      </tr>
      <tr>
        <td align="right" style="width:1in">
          <b>Ship To:</b>
        </td>
        <td style="width:3.5in; font-size:14px">
          <div><?php echo $custfullname ?></div>
          <div> <?php echo $custaddress ?></div>
           <div> <?php echo $custcity ?>,<?php echo $custstate ?>  <?php echo $custzip ?></div>
        </td>
        <td style="width:2.5in">
          <table cellspacing="0" border="0" class="order-info">
            <tr>
              <td align="right" class="label first">Order #</td>
              <td> <?php  echo $custOrderNumber ?></td>
            </tr>
            <tr>
              <td align="right" class="label">Date</td>
              <td><?php  echo $datecreate ?></td>
            </tr>
            <tr>
              <td align="right" class="label last">Ship Date</td>
              <td><?php echo $date?></td>
            </tr>
          </table>
        </td>
      </tr>
    </tbody>
  </table>

  <table cellspacing=0 cellpadding="2" border="0" style="width:8in" class="line-items">
    <thead>
      <tr>
        <th align="left" style="width:3in" class="sku">
          Quantity
        </th>   
        <th align="right" style="width:8in" class="price">
         Item
        </th>     
        <th align="right" style="width:3in" class="price">
          Ext. Price
        </th>
      </tr>
    </thead>
    <tbody>

    <?php 
         $e = 0; 
         foreach ($pieces as $data) {$e++;}
         for($i = 0; $i < $e-1; $i++ ){?>                        
        <tr class="item">
        <td style="text-align: left;"><?php echo $pieces[$i] ?> </td>
         <?php $i++; ?> 
        <td><?php echo $pieces[$i]?> </td>
        
        <?php 
        $pieces[$i]= trim($pieces[$i]);
        for($j = 0; $j <= 140; $j++ ){      
        if ($productDesc[$j] ==  $pieces[$i]) {
        $productPriceTotal = $productPrice[$j] * $pieces[$i-1];}}
            
        ?>   
            
        <td style="text-align: right;"><?php echo "$".number_format($productPriceTotal, 2) ?></td>
        </tr>  
        <?php  }
        
       ?>   
      
    </tbody>
  </table>

  <table cellspacing=0 cellpadding="2" border="0" style="width:8in" class="footer">
   
    <tbody>
      <tr>
        <td align="right" class="label price">
          Sub Total:
        </td>
        <td style="width:1in" align="right" class="price"><?php  echo "$" .number_format($subtotalcharge, 2)?></td>
      </tr>
      <tr>
        <tr class="tax">
          <td align="right" class="label price">
            Tax:
          </td>
          <td style="width:1in" align="right" class="price"><?php  echo "$" .number_format($tax, 2)?></td>
        </tr>
        <tr>
          <td align="right" class="label price">
            Shipping:
          </td>
          <td style="width:1in" align="right" class="price"><?php  echo "$" .number_format($shippingcharge, 2)?></td>
        </tr>
        <tr>
          <td align="right" class="label price">
            Total:
          </td>
          <td style="width:1in" align="right" class="price"><?php  echo "$" .number_format($totalorder, 2)?></td>
        </tr>
    </tbody>
  </table>
     <br> <br>
     
     
  <h2 style="text-align: left">Shipping Label </h2>     
     
 <table cellspacing=0 cellpadding="2" border="0" style="width:8in">
     <tr>
	   <td style="text-align: left">
	   Amplified Auto Parts, Inc.<br />
	   12010 Rustic Trails Road<br />
	   DeKalb, IL 60115
	  </td>

          <td></td> 
           <td></td>                                                      
         
	 </td>
     </tr>
     
     <tr>	   
          <td></td> 
           <td></td>                                                      
          <td style="text-align: right"><font size="+2">
	 <?php echo $custfullname ?><br />
	 <?php echo $custaddress ?><br />
	 <?php echo $custcity ?>,<?php echo $custstate ?>  <?php echo $custzip ?> <br />
         <?php echo $custemail ?>
	 </td>
     </tr>
        
   </table>


      
        
  </div>
     
     <h3 style="text-align:center"> Are you sure you want to complete this order?</h3>
     
      <div style="text-align:center" class="action_btn">

     <input type=submit onClick="choosepage1()" id="btSubmit" name="confirm"class="action_btn submit" value="Complete Order" style="font-size: 2em;color: red;height:50px;width:40%"> 
    <input type=button onClick="choosepage2()"id="btSubmit" name="confirm" class="action_btn cancel"value="Cancel" style="font-size: 2em;color: red;height:50px;width:40%">
         <p id="saved"></p>

            </div>

        
     
   
    <script>
             function choosepage1() {
               window.location.href="adminwaresubmit.php";
             }   
             function choosepage2() {
               window.location.href="adminwarehouse.php";
           }      
             
            </script> 
    
    
    <input type="hidden" id="replace" name="replace" value ="<?php  echo $custOrderNumber?>">
    <input type="hidden" id="ema" name="ema" value ="<?php  echo $custemail?>">
    
         </form>

    </main> 
            
        <footer>
            
        Copyright &copy; 2022. Amplified Auto Parts, INC. All rights reserved. <br> 
     
        </footer> 
         </div>
    </body>
</html>


