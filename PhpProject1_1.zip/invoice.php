<?php
		$hostName = "localhost:3306";
		$userName = "root";
		$password = "";
		$databaseName = "csci467";
		try{
			//$dsn = "mysql:host = localhost:3306, dbname=csci467";
			$conn = mysqli_connect("localhost:3306","root","","csci467");
			$sql ="SELECT `description` FROM parts";
			$res= mysqli_query($conn,$sql);
			//$result= mysql_query("SELECT * FROM parts");
			
			
			//echo '<option value="'.$getID.'">'.$getName.'</option>';
			
		} catch(PDOException $e){
			echo 'Caught exception:'.$e->getMessage();
		}
		
?>
<!DOCTYPE html>
<html lang="en">    
    <head>        
        <title>Receiving Console</title>
        <meta charset="utf-8">  
        <meta name="viewport" content="width=device-width initial-scale=1.0">
        <link href="autoparts.css" rel="stylesheet" type="text/css"> 
        
    <style>
        body {margin:0;
        padding-top: 7.8em;}

        .navbar {
          overflow: hidden;
          background-color: black;
          position: fixed;
          top: 0;
          width: 100%;
          height: 120px; 
          margin-right: 2em;
        }

        .navbar a {
          float: left;
          display: block;
          color: #f2f2f2;
          text-align: center;
          padding: 14px 16px;
          text-decoration: none;
          font-size: 27px;
          margin-right: 2em;
        }

        .navbar a:hover {
          background: #ddd;
          color: black;
        }

        .main {
          padding: 16px;
          margin-top: 30px;
          height: 1500px; /* Used in this example to enable scrolling */
        }
        
        input{font-size: 18px;}
        
        </style>
        </script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
			<script type="text/javascript">
			$(document).ready(function(){
				var maxField = 10; //Input fields increment limitation
				var addButton = $('.add_button'); //Add button selector
				var wrapper = $('.field_wrapper'); //Input field wrapper
				var fieldHTML = '<div><select><option value="<?php echo $rows['description'];?>">'
				+ '<input type="text" name="field_name[]" value=""/>'
				+'<a href="javascript:void(0);" class="remove_button"><img src="remove-icon.png"/></a></option></select></div>'; //New input field html 
				var x = 1; //Initial field counter is 1
    
			//Once add button is clicked
				$(addButton).click(function(){
        //Check maximum number of input fields
					if(x < maxField){ 
						x++; //Increment field counter
						$(wrapper).append(fieldHTML); //Add field html
					}
				});
    
			//Once remove button is clicked
				$(wrapper).on('click', '.remove_button', function(e){
					e.preventDefault();
					$(this).parent('div').remove(); //Remove field html
					x--; //Decrement field counter
				});
			});
			</script>  		
    </head>
    <body>
        
         <div id="wrapper">   
        <header>
            <h1>Amplified Auto Parts</h1>
        </header>
  
             <main>
        <h2 style="color: blue; text-align: center"><font size="+4"> Receiving Invoice Management <font size="+0"></h2>
        <h2> INVOICE FORM </h2>
		<pre>
		select product:
		<select>
			<?php while ($rows = mysqli_fetch_array($res)){
				?>
			
				<option value="<?php echo $rows['description'];?>">
				<a href="javascript:void(0);" class="add_button" title="Add field"><img src="add-icon.png"/></a>				
				<?php echo $rows['description'];?>
				
				</option>
			<?php 
			}
			?>
		</select>
		</pre>		
		<form action="adminreceiveconfirm.php" method="post">    
            
         <div class="navbar">
             <a href="adminmenu.php">Main Menu</a>
             <a href="adminwarehouse.php">Warehouse</a>
            <a><span>Filter results by part number or description</span></a>
            <a><span><input type="text" id="myInput" onkeyup="myFunction()" placeholder="Search"> </span></a>
<!--            <a><span>Total Items Added: </span></a>
            <a><span id="sum">0</span></a>          -->
                 
          </div>
		<div class='left'>  
  
		<pre>
		aaaaaaaaaaaaaaaaaaaaaaaa
		</pre>
		</div>
		
        </main>         
        <footer>        
        Copyright &copy; 2022. Amplified Auto Parts, INC. All rights reserved. <br> 
     
        </footer> 
         </div>  
    </body>
</html>