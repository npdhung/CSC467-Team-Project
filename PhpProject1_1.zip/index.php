<!DOCTYPE html>
<html lang="en">    
    <head>        
        <title>Amplified Auto Parts</title>
        <meta charset="utf-8"> 
        <meta name="viewport" content="width=device-width initial-scale=1.0">
        <link href="autoparts.css" rel="stylesheet" type="text/css"> 
    </head>
    <body>
        
        <div id="wrapper">
        
        <header>
            <h1>Amplified Auto Parts</h1>
        </header>
        
        <nav>
            <ul> 
            <li><a href="index.php">Home</a></li>
            <li><a href="partscatalog.php">Parts Catalog</a></li>
            <li><a href="adminlogin.php">Company Portal</a></li>
 
            </ul>           
        </nav>
        
         <div id="homehero"></div>
            
        <main>
                       
        <h2>Your Online Auto Parts Store</h2>
        
        <p>
            <span class="resort">Amplified Auto Parts</span> offers quality auto parts at a reasonable price.  
        </p>
        
        
        <ul>
            <li> Browse our Online Catalog to order parts from our online warehouse.</li>
            <li> Follow us on Twitter <a href="http://www.twitter.com/amplified_auto" target="_blank">@amplified_auto</a> for special deals and see what we can do for you.</li>
            <li> We ship directly to your home or business.</li><br>
            
        </ul>
            <br>
        
        <div id="contact">
            <span class="resort">Amplified Auto Parts</span><br>
            12010 Rustic Trails Road <br>
            DeKalb, IL 60115 <br> <br>
            <a id="mobile" href="tel:888-555-5555">888-555-5555</a>
            <span id="desktop">Customer Service: 888-555-5555</span>
            <br> <br>
        </div>
            
          
         </main>
            
        <footer>
            Copyright &copy; 2022. Amplified Auto Parts, INC. All rights reserved. <br>       
        </footer> 
            
        </div> 
        
    </body>
    
</html>
