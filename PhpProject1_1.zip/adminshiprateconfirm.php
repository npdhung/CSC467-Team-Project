<?php
              $document_root = $_SERVER['DOCUMENT_ROOT'];          
                $delim = ","; 
                $status= file("$document_root/Auto Parts/database/shippingrates.txt");
                //$number_of_orders = count($status);
                
                      $weightArray = array();
                      $priceArray = array();
                      $k = 0;
                      $kk = 0;
                      $lines = explode($delim, $status[0]);
                      foreach ($lines as $val) {  
                      $weightArray[] = $val;
                      $k++;}
                      $lines = explode($delim, $status[1]);
                      foreach ($lines as $val) {  
                      $priceArray[] = $val;
                      $kk++;}             
              $weightadd = (string) $_POST['TextWeightAdd'];
              $weightaddArray = (explode(",",$weightadd));             
              $priceadd = (string) $_POST['TextPriceAdd'];
              $priceaddArray = (explode(",",$priceadd));             
              $weightdel = (string) $_POST['TextWeightDel'];
              $weightdelArray = (explode(",",$weightdel));            
              $pricedel = (string) $_POST['TextPriceDel'];            
              $pricedelArray = (explode(",",$pricedel)); 
              $outputweight = "";
              $outputprice = "";
                           
              $weightAddArr = array_merge($weightArray, $weightaddArray);
              $priceAddArr = array_merge($priceArray, $priceaddArray);
              
              $clean1 = array_diff($weightAddArr, $weightdelArray); 
              $clean2 = array_diff($weightdelArray, $weightAddArr); 
              $weightFinal = array_merge($clean1, $clean2);
                          
              $clean3 = array_diff($priceAddArr, $pricedelArray); 
              $clean4 = array_diff($pricedelArray, $priceAddArr); 
              $priceFinal = array_merge($clean3, $clean4);
                             
              sort($weightFinal);
              $clength=count($weightFinal);
                for($x=0;$x<$clength;$x++){
                   $outputweight  .= ",$weightFinal[$x]"; }  
                   $outputweight = substr($outputweight, 1);
                            
              sort($priceFinal);
              $clength2=count($priceFinal);
                for($x=0;$x<$clength2;$x++){
                  $outputprice  .= ",$priceFinal[$x]"; }     
                  $outputprice = substr($outputprice, 1);
                  
               $fp = fopen("$document_root/Auto Parts/database/shippingrates.txt", 'w');

               if (!$fp){    
                 echo "<p><strong> There was an internal connection problem.  Please try again later. </strong></p>";
                 exit;       
                }
                flock($fp, LOCK_EX);
               fwrite($fp, $outputweight, strlen($outputweight));
               fwrite($fp, $outputprice, strlen($outputprice));
               flock($fp, LOCK_UN);
                fclose($fp);   
                
       ?>
<!DOCTYPE html>
<html lang="en">    
    <head>        
        <title>Shipping Rates Confirmation</title>
        <meta charset="utf-8">  
        <meta name="viewport" content="width=device-width initial-scale=1.0">
        <link href="autoparts.css" rel="stylesheet" type="text/css"> 
                  
</head>
    <body>
         <div id="wrapper">    
        <header>
            <h1>Amplified Auto Parts</h1>
        </header>
        
        <nav>
            <ul> 
             <li><a href="index.php">Home</a></li>
            <li><a href="partscatalog.php">Parts Catalog</a></li> 
            </ul>           
        </nav>
    <main>      
                                
       <h2> Your rates have been changed </h2>
           
           <form action="adminorders.php" method="post">
             <input type=submit id="btSubmit" value="Continue to Administration Console" style="font-size: 2em;color: red;height:50px;width:75%"> 
                   
       </form>   
     </main> 
            
        <footer>
            
        Copyright &copy; 2022. Amplified Auto Parts, INC. All rights reserved. <br> 
     
        </footer> 
         </div>
    </body>
</html>


