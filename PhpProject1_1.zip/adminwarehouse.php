<?php
 $inputstring = "";
 $ordersArray =array();

// create short variable name
$document_root = $_SERVER['DOCUMENT_ROOT'];
date_default_timezone_set('America/Chicago');
$date = date('m/d/Y h:i:s a', time());
$tomorrow = date("m/d/Y", strtotime("+1 day"));     

?>

<!DOCTYPE html>
<html lang="en">    
    <head>        
        <title>Order Fulfillment</title>
        <meta charset="utf-8">  
        <meta name="viewport" content="width=device-width initial-scale=1.0">
        <link href="autoparts.css" rel="stylesheet" type="text/css"> 
        
         <style>
* {box-sizing: border-box;}

#myInput {
  background-image: url('/css/searchicon.png');
  background-position: 10px 10px;
  float: right;
  background-repeat: no-repeat;
  width: 20%;
  font-size: 16px;
  padding: 12px 20px 12px 40px;
  border: 1px solid #ddd;
  margin-bottom: 12px;
}

label {
  width:150px;
  display: inline-block;
}
button{
 margin-left: 210px;}



</style>   
</head>
    <body>
         <div id="wrapper">    
        <header>
            <h1>Amplified Auto Parts</h1>
        </header>      
        <nav>
            <ul> 
              <li><a href="adminmenu.php">Company Portal Main Menu</a></li>
              <li><a href="adminreceiving.php">Receiving Console</a></li>        
            </ul>           
        </nav>
    <main>  
         <form action="adminwareconfirm.php" method="post"> 
             
    <h3 style="text-align: center">Order Fulfillment  <?php echo $date?></h3>  
       <?php    
        //Read in the entire file. Each order becomes an element in the array
        $delimiter = "^"; 
        $orders= file("$document_root/Auto Parts/database/orders.txt");
        // count the number of orders in the array
        $number_of_orders = count($orders);
        if ($number_of_orders == 0) {
        echo "<p><strong>No orders pending.<br />
        Please try again later.</strong></p>";
        } 
        else{
    $orderflag = 0;
    $countr = 0;
    $indx = 0;
    $c = 0;
    for ($i=0; $i<$number_of_orders; $i+=1) {
       $line = explode($delimiter, $orders[$i]);  
          foreach ($line as $value) {
            if($value == "open"){
               $orderflag = 1;
               $countr ++;}
            if($value == "filled"){
               $orderflag = 0;}                         
            if($orderflag == 1){    
             if($c == 0){$orderStatArray[$countr] = $value;}              
             if($c == 1){$orderDateArray[$countr] = $value;}
             if($c == 2){$orderAuthArray[$countr] = $value;}
             if($c == 3){$orderNoArray[$countr] = $value;}
             if($c == 4){$orderNameArray[$countr] = $value; } 
             if($c == 5){$orderEmailArray[$countr] = $value; }
             if($c == 6){$orderAddressArray[$countr] = $value; }   
             if($c == 7){$orderCityArray[$countr] = $value; }       
             if($c == 8){$orderStateArray[$countr] = $value; }  
             if($c == 9){$orderZipArray[$countr] = $value; }  
             if($c == 10){$orderWtArray[$countr] = $value;}
             if($c == 11){$orderShipArray[$countr] = $value;}
             if($c == 12){$orderAmtArray[$countr] = $value;}    
             if($c >= 13){ 
                 $inputstring  .= "$value^"; 
                 $ordersArray[$countr-1] =  $inputstring;}}
          $c ++;} 
          $c = 0;
          $inputstring = "";        
        }} ?>    
    
  <table id="order-table"  class="table-info table">             
      <?php
      $counter = 0;
      for($i = 1; $i <= $countr ; $i+=1 ){ ?>       
      
      <tr style="background: #cccccc;">
      <td style="width: 150px; text-align: center;"></td>
      <td style="width: 200px; text-align: center;"></td> 
      <td style="width: 200px; text-align: center;"></td>
      <td style="width: 200px; text-align: center;"></td>
    </tr>      
      
    <tr style="background: lightgrey;">
      <td><font size="+1.5">Order No: <?php  echo $orderNoArray[$i] ?></td>
      <td><font size="+1.5"> <?php echo "$" .number_format($orderAmtArray[$i], 2)."</>" ?> </font></td>
      <td><font size="+1.5">Weight: <?php  echo $orderWtArray[$i] ?> lbs.</font></td> 
        <td><input type=submit onClick="myFunction()"id= '<?php echo "btnfull".$i?>' value="Complete Order" style="font-size:1.5em;color: red">  </td>      
    </tr>  
   
     <?php 
     $counter += 1;  
      } ?>        
   
    </table> 

<h2 style="text-align: left">Orders Found:   <?php  echo $countr ?> </h2>

<input type="hidden" id="ordernumber" name="ordernumber">
<input type="hidden" id="shipnumber" name="shipnumber">
<input type="hidden" id="amtnumber" name="amtnumber">
<input type="hidden" id="namenumber" name="namenumber">
<input type="hidden" id="addressnumber" name="addressnumber">
<input type="hidden" id="citynumber" name="citynumber">
<input type="hidden" id="statenumber" name="statenumber">
<input type="hidden" id="zipnumber" name="zipnumber">
<input type="hidden" id="emailnumber" name="emailnumber">
<input type="hidden" id="datenumber" name="datenumber">
<input type="hidden" id="authnumber" name="authnumber">
<input type="hidden" id="shipwt" name="shipwt">

<input type="hidden" id="refno" name="refno">
<input type="hidden" id="prod" name="prod"value="  <?php  echo $ordersArray[0] ?>">

<INPUT TYPE="hidden" NAME="orderproducts" VALUE="<?= base64_encode(serialize($ordersArray)); ?>">
<?php
?>

<script>
function myFunction() { 
     var order1 = [<?php echo '"'.implode('","', $orderNoArray).'"' ?>];
     var order2 = [<?php echo '"'.implode('","', $orderShipArray).'"' ?>];
     var order3 = [<?php echo '"'.implode('","', $orderAmtArray).'"' ?>];
     var order4 = [<?php echo '"'.implode('","', $orderNameArray).'"' ?>];
     var order5 = [<?php echo '"'.implode('","', $orderAddressArray).'"' ?>];
     var order6 = [<?php echo '"'.implode('","', $orderCityArray).'"' ?>];
     var order7 = [<?php echo '"'.implode('","', $orderStateArray).'"' ?>];
     var order8 = [<?php echo '"'.implode('","', $orderZipArray).'"' ?>];
     var order9 = [<?php echo '"'.implode('","', $orderEmailArray).'"' ?>];
     var order10 = [<?php echo '"'.implode('","', $orderDateArray).'"' ?>];
     var order11 = [<?php echo '"'.implode('","', $orderAuthArray).'"' ?>];
     var order12 = [<?php echo '"'.implode('","', $orderWtArray).'"' ?>];     
     var cou = 0;
     for (i = 0; i < 50; i++) {
      if( event.target.id === "btnfull"+i) { 
         document.getElementById("ordernumber").value = order1[i-1]; 
         document.getElementById("shipnumber").value = order2[i-1]; 
         document.getElementById("amtnumber").value = order3[i-1]; 
         document.getElementById("namenumber").value = order4[i-1]; 
         document.getElementById("addressnumber").value = order5[i-1]; 
         document.getElementById("citynumber").value = order6[i-1]; 
         document.getElementById("statenumber").value = order7[i-1]; 
         document.getElementById("zipnumber").value = order8[i-1]; 
         document.getElementById("emailnumber").value = order9[i-1];
         document.getElementById("datenumber").value = order10[i-1];
         document.getElementById("authnumber").value = order11[i-1];
         document.getElementById("refno").value = cou;
         document.getElementById("shipwt").value = order12[i-1];       
     }
     cou ++;
 } 
}
</script>

         </form>

    </main> 
            
        <footer>
            
        Copyright &copy; 2022. Amplified Auto Parts, INC. All rights reserved. <br> 
     
        </footer> 
         </div>
    </body>
</html>

