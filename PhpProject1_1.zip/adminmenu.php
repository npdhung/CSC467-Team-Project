<?php

?>

<!DOCTYPE html>
<html lang="en">    
    <head>        
        <title>Company Portal Main Menu</title>
        <meta charset="utf-8">  
        <meta name="viewport" content="width=device-width initial-scale=1.0">
        <link href="autoparts.css" rel="stylesheet" type="text/css"> 
                  
</head>
    <body>
         <div id="wrapper">    
        <header>
            <h1>Amplified Auto Parts</h1>
        </header>
        
        <nav>
            <ul> 
             <li><a href="index.php">Home</a></li>
            <li><a href="partscatalog.php">Parts Catalog</a></li> 
            </ul>           
        </nav>
    <main>      
                                
       <h2 style="color: blue; text-align: center"><font size="+4"> Company Portal Main Menu <font size="+0"></h2>
       
           <input type=submit onClick="choosepage2()"id="btSubmit" value="Administration Console" style="font-size: 2em;color: red;height:50px;width:75%"> 
           <input type=submit onClick="choosepage3()" id="btSubmit" value="Warehouse Console" style="font-size: 2em;color: red;height:50px;width:75%">          
           <input type=submit onClick="choosepage4()"id="btSubmit" value="Receiving Console" style="font-size: 2em;color: red;height:50px;width:75%"> 
            
            <script>
             function choosepage2() {
               window.location.href="adminorders.php";
             }   
             function choosepage3() {
               window.location.href="adminwarehouse.php";
           }      
             function choosepage4() {
               window.location.href="adminreceiving.php"; 
             }   
             
               function choosepage1() {
               window.location.href="adminlogin.php"; 
             }   
            </script> 
            

         <div class="container">
         <button class="cancelbtn" onClick="choosepage1()" style="margin-left: 7.1em;font-size: 2em;color: red;height:50px;width:60%"onclick="window.location.href='index.php'">Logout</button>
         </div>            
       
     </main> 
            
        <footer>
            
        Copyright &copy; 2022. Amplified Auto Parts, INC. All rights reserved. <br> 
     
        </footer> 
         </div>
    </body>
</html>