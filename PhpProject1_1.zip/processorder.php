<?php
         $hostName = "blitz.cs.niu.edu:3306";
        $userName = "student";
        $password = "student";
        $databaseName = "csci467";
        $mysqli = new mysqli($hostName, $userName, $password, $databaseName);
        
        // Check connection
        if ($mysqli->connect_error) {
            die('Connect Error (' .
            $mysqli->connect_errno . ') '.
            $mysqli->connect_error);}
          
         // SQL query to select data from database
            $sql = " SELECT * FROM parts ORDER BY number LIMIT 141 OFFSET 0 ";
            $result = $mysqli->query($sql);
            $mysqli->close();

            $productDesc = array();
            $productPrice = array();
            $loop = 0;
                // LOOP TILL END OF DATA
                while($rows=$result->fetch_assoc())
                {
                 $productPartNo[$loop] = $rows['number'];   
                 $productPict[$loop] = $rows['pictureURL'];
                 $productDesc[$loop] = $rows['description'];
                 $productPrice[$loop] = $rows['price'];
                 $productWeight[$loop] = $rows['weight'];           
                 $loop++; 
                }          

    $orderQuantities = $_POST['parts']; 
    
    $totalqty = (int) $_POST['totalsum'];
    $subtotalamount = (float) $_POST['subtotalval'];
    $productWeightTotal = 0;
    $shippingtotal = 0.00; 
    $taxrate = 0.0885;
    $tax = ($subtotalamount * $taxrate);
    $totalamounts = ($subtotalamount * (1 + $taxrate)) + $shippingtotal; 
    $totalamount = round($totalamounts, 2);
    
    session_start();   
    $_SESSION['orderqtys'] =  $orderQuantities ;
    
    //Read in the entire file. Each order becomes an element in the array
       $document_root = $_SERVER['DOCUMENT_ROOT'];              
    $delim = ","; 
    $status= file("$document_root/Auto Parts/database/shippingrates.txt");
       $k = 0;
       $kk = 0;
       $lines = explode($delim, $status[0]);
       foreach ($lines as $val) {  
       ${'weightval'.$k} = sprintf("%03d", $val);
       $k++;}
       $lines = explode($delim, $status[1]);
       foreach ($lines as $val) {  
       ${'priceval'.$kk} = $val;
       $kk++;}
    ?>

<!DOCTYPE html>
<html lang="en">    
    <head>        
        <title>Amplified Auto Parts : Order Form</title>
        <meta charset="utf-8">  
        <meta name="viewport" content="width=device-width initial-scale=1.0">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <script>
           function enableSubmit(){
   let inputs = document.getElementsByClassName('req');
   let btn = document.querySelector('input[type="submit"]');
   let isValid = true;

   for (var i = 0; i < inputs.length; i++){
     let changedInput = inputs[i];
     if (changedInput.value.trim() === "" || changedInput.value === null){
       isValid = false;
       break;
     }
   }
   btn.disabled = !isValid;
 }  
            
            
            
            </script>     
    <style>
   body {
  background-color: beige; 
    color: black;
  font-family: Arial;
  font-size: 10px;
  padding: 8px;
}

nav { padding: 0.5em;
        float:none;
        width: auto;
        text-align: center;}

nav li { display: inline;
         padding-top: 0.25em; padding-bottom: 0.25em;
         padding-left: 0.75em; padding-right: 0.75em;}

nav a { text-decoration: none;}

nav ul {list-style-type: none;
        padding-left: 0;
        font-size: 1.2em;     }

nav a:link {color: #5C7FA3;}

nav a:visited {color: #344873;}

nav a:hover {color: #A52A2A;}


* {
  box-sizing: border-box;
}

.row {
  display: -ms-flexbox; /* IE10 */
  display: flex;
  -ms-flex-wrap: wrap; /* IE10 */
  flex-wrap: wrap;
  margin: 0 -16px;
}

.col-25 {
  -ms-flex: 50%; /* IE10 */
  flex: 50%;
}

.col-50 {
  -ms-flex: 50%; /* IE10 */
  flex: 50%;
}

.col-75 {
  -ms-flex: 75%; /* IE10 */
  flex: 75%;
}

.col-25,
.col-50,
.col-75 {
  padding: 0 16px;
}

.container {
  background-color: #f2f2f2;
  padding: 5px 20px 15px 20px;
  border: 1px solid lightgrey;
  border-radius: 3px;
}

input[type=text] {
  width: 100%;
  margin-bottom: 20px;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 3px;
}

label {
  margin-bottom: 10px;
  display: block;
}

.icon-container {
  margin-bottom: 20px;
  padding: 7px 0;
  font-size: 50px;
}

.btn {
  background-color: #04AA6D;
  color: white;
  padding: 12px;
  margin: 10px 0;
  border: none;
  width: 100%;
  border-radius: 3px;
  cursor: pointer;
  font-size: 19px;
}

.btn:hover {
  background-color: #45a049;
}

a {
  color: #2196F3;
  font-size: 1.1em;
}

hr {
  border: 1px solid lightgrey;
}

span.price {
  float: right;
  color: grey;
  font-size: 1.1em;
}

/* Responsive layout - when the screen is less than 800px wide, make the two columns stack on top of each other instead of next to each other (also change the direction - make the "cart" column go on top) */
@media (max-width: 800px) {
  .row {
    flex-direction: column-reverse;
  }
  .col-25 {
    margin-bottom: 20px;
  }
}     
         
	    </style>        
            
<!--The following script tag downloads a font from the Adobe Edge Web Fonts server for use within the web page. We recommend that you do not modify it.--><script>var __adobewebfontsappname__="dreamweaver"</script><script src="http://use.edgefonts.net/abel:n4:default;actor:n4:default;source-sans-pro:n4,n3,n2,n7,n9:default;kristi:n4:default;mr-dafoe:n4:default;pacifico:n4:default;sofia:n4:default.js"></script>
</head>
  
<body style="padding-top: 70px; padding-left: 70px;font-size: medium;">
    
    <nav>
            <ul> 
             <li><a href="index.php">Home</a></li>
            <li><a href="partscatalog.php">Parts Catalog</a></li>
            
            </ul>           
        </nav>
    <h1 style="text-align: center"><font size="+7">Amplified Auto Parts Order Form</h1>
    
<div class="row">
    
    
    <div class="col-25">
    <div class="container">
          
        <h4>Cart <span class="price" style="color:black"><font size="+3.5"><i class="fa fa-shopping-cart" ></i> <b> <?php echo $totalqty ?></b></span></h4>
       
         <table>              
        <tr style="background: #cccccc;">
          <td style="width: 600px; text-align: left;"> Item</td>
          <td style="width: 200px; text-align: center;">Quantity </td> 
          <td style="width: 350px; text-align: center;">Price Per Unit </td> 
          <td style="width: 200px; text-align: right;">Total </td> 
        </tr>  
         </table>
        
       <?php 
       for($i = 0; $i <= 140; $i++ ){      
         if ($orderQuantities[$i] > 0) {
             $productPriceTotal = $productPrice[$i] * $orderQuantities[$i];
             $productWeightTotal += ($productWeight[$i] * $orderQuantities[$i]);?>  
         <table>              
        <tr>
          <td style="width: 600px; text-align: left;"><?php echo htmlspecialchars($productDesc[$i])?> </td>
          <td style="width: 200px; text-align: center;"><?php echo htmlspecialchars($orderQuantities[$i])?> </td>
          <td style="width: 350px; text-align: center;"><?php echo "$".number_format($productPrice[$i], 2) ?></td>
          <td style="width: 200px; text-align: right;"><?php echo "$".number_format($productPriceTotal, 2) ?></td>
        </tr>  
         </table>

       <?php }    
            }
    
           if ($productWeightTotal< 1) {
             $shippingtotal = 0.00;           
           }else{
             $ctr = -1;
            for($z = 0; $z < $k; $z++){     
            if($productWeightTotal < ${'weightval'.$z} ){
            $shippingtotal = ${'priceval'.$ctr};
            break;        
            } 
            $ctr++;
        }
        }
         $totalamount = $totalamount + $shippingtotal;                
            ?>     
      <hr>
      <p>Subtotal <span class="price" style="color:black"><b> <?php  echo "$" .number_format($subtotalamount, 2)."<br />" ?> </b></span></p>
      <p>Tax at 8.85% <span class="price" style="color:black"><b> <?php  echo "$" .number_format($tax, 2)."<br />" ?> </b></span></p>
      
      <p>Shipping Charge for Total Weight at  <?php echo $productWeightTotal?>  lbs. <span class="price" style="color:black"><b> <?php  echo "$" .number_format($shippingtotal, 2)."<br />" ?> </b></span></p>
      <p>Order Total <span class="price" style="color:black"><b> <?php  echo "$" .number_format($totalamount, 2)."<br />" ?> </b></span></p>
    </div>
  </div>
     </div>
     <h1 style="text-align: center"><font size="+7">Payment Method</h1>
    
  <div class="col-75">
    <div class="container">
      <form action="orderconfirm.php" method="post">
       
        <div class="row">
          <div class="col-50">
            <h3>Billing Address</h3>
            <label for="fname"><i class="fa fa-user"></i> Full Name</label>
            <input type="text" class='req' id="fname" name="fullname" onkeyup='enableSubmit()' required>
            <label for="email"><i class="fa fa-envelope"></i> Email</label>
            <input type="text" class='req' id="email" name="email" onkeyup='enableSubmit()' required>
            <label for="adr"><i class="fa fa-address-card-o"></i> Address</label>
            <input type="text" class='req' id="addr" name="address" onkeyup='enableSubmit()' required>
            <label for="city"><i class="fa fa-institution"></i> City</label>
             <input type="text" class='req' id="city" name="city" onkeyup='enableSubmit()' required>

            <div class="row">
              <div class="col-50">
                <label for="state">State</label>
                 <input type="text" class='req' id="state" name="state" onkeyup='enableSubmit()' required>
              </div>
              <div class="col-50">
                <label for="zip">Zip</label>
                <input type="text" class='req' id="zip" name="zip" onkeyup='enableSubmit()' required>
              </div>
            </div>
          </div>

          <div class="col-50">
            <h3>Payment</h3>
            <label for="fname">Accepted Cards</label>
            <div class="icon-container">
              <i class="fa fa-cc-visa" style="color:navy;"></i>
              <i class="fa fa-cc-amex" style="color:blue;"></i>
              <i class="fa fa-cc-mastercard" style="color:red;"></i>
              <i class="fa fa-cc-discover" style="color:orange;"></i>
            </div>
            <label for="cname">Name on Card</label>
            <input type="text" class='req' id="cname" name="cardname" onkeyup='enableSubmit()' required>
            <label for="ccnum">Credit card number</label>
            <input type="text" class='req' id="ccnum" name="cardnumber" placeholder="xxxx xxxx xxxx xxxx" onkeyup='enableSubmit()' required>
            <label for="expmonth">Exp Month/Year</label>
            <input type="text" class='req' id="expmonth" name="expmonth" placeholder="xx/xxxx"onkeyup='enableSubmit()' required>
            <label for="cvv">CVV</label>
            <input type="text" class='req' id="cvv" name="cvv" placeholder="xxx" onkeyup='enableSubmit()' required>
            
          </div>
          
        </div>
          
        <label>
        <label for="myCheck">Shipping address different than billing?</label> 
        <input type="checkbox" id="myCheck" name="Yes" onclick="myFunction()"> 
        <label for="Yes" style="font-size: 22px">Yes</label>
         <p id="text" style="display:none">Shipping Address         
             <label> <br></label>
            <label for="adr"><i class="fa fa-address-card-o"></i> Address</label>
            <input type="text" id="adr" name="shipaddress" >
            <label for="city"><i class="fa fa-institution"></i> City</label>
            <input type="text" id="city" name="shipcity" > 
                <label for="state">State</label>
                <input type="text" id="state" name="shipstate">     
                <label for="zip">Zip</label>
                <input type="text" id="zip" name="shipzip"> </p>
              

<script>
function myFunction() {
  var checkBox = document.getElementById("myCheck");
  var text = document.getElementById("text");
  if (checkBox.checked === true){
    text.style.display = "block";
  } else {
     text.style.display = "none";
  }
}
</script>
        
        </label>
        <input type="hidden" name="purchaseAmount" value="<?php echo $totalamount; ?>">
        <input type="hidden" id="shiptotal" name="shiptotal" value="<?php echo $shippingtotal; ?>">
        <input type="hidden" id="subtotal" name="subtotal" value="<?php echo $subtotalamount; ?>">
         <input type="hidden" id="tax" name="tax" value="<?php echo $tax; ?>">
        <input type="submit" value="Place your order" class="btn">
     
        
      </form>
    </div>
  </div>
  



    
    
  </body>
</html>

