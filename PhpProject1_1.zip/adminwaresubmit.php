<?php
$custOrderNumbers  = (float) $_POST['replace'];
$custemails  = (string) $_POST['ema'];
$document_root = $_SERVER['DOCUMENT_ROOT'];
 $inputstring = "";
 $outputstring = "";
       //Read in the entire file. Each order becomes an element in the array
        $delimiter = "^"; 
        $orders= file("$document_root/Auto Parts/database/orders.txt");
        // count the number of orders in the array
        $number_of_orders = count($orders);
        $c = 0;
         for ($i=0; $i<$number_of_orders; $i+=1) {
       $line = explode($delimiter, $orders[$i]);
       
        foreach ($line as $value) {
             if($c == 0){$orderStatArray[$i] = $value;}              
             if($c == 1){$orderDateArray[$i] = $value;}
             if($c == 2){$orderAuthArray[$i] = $value;}
             if($c == 3){
               if ($value ==  $custOrderNumbers) {
                $orderStatArray[$i]  = "filled";}      
                $orderNoArray[$i] = $value;}
             if($c == 4){$orderNameArray[$i] = $value; } 
             if($c == 5){$orderEmailArray[$i] = $value; }
             if($c == 6){$orderAddressArray[$i] = $value; }   
             if($c == 7){$orderCityArray[$i] = $value; }       
             if($c == 8){$orderStateArray[$i] = $value; }  
             if($c == 9){$orderZipArray[$i] = $value; }  
             if($c == 10){$orderWtArray[$i] = $value;}
             if($c == 11){$orderShipArray[$i] = $value;}
             if($c == 12){$orderAmtArray[$i] = $value;}    
             if($c >= 13){ 
                 $inputstring  .= "^$value"; 
                 $ordersArray[$i] =  $inputstring;
             }
          $c++;
         }
         $ordersArray[$i]= trim($ordersArray[$i]);
        $ordersArray[$i] = substr($ordersArray[$i], 1);
        $inputstring = ""; 
        $c=0;
         }      
        $fp = fopen("$document_root/Auto Parts/database/orders.txt", 'w');
        flock($fp, LOCK_EX);
        for ($j=0; $j<$number_of_orders; $j+=1) {                   
               $outputstring = $orderStatArray[$j]."^".$orderDateArray[$j]."^".$orderAuthArray[$j]."^".$orderNoArray[$j]."^".$orderNameArray[$j]."^".$orderEmailArray[$j]."^".$orderAddressArray[$j]."^".$orderCityArray[$j]."^".$orderStateArray[$j]."^".$orderZipArray[$j]."^".$orderWtArray[$j]."^".$orderShipArray[$j]."^".$orderAmtArray[$j]."^".$ordersArray[$j]."\n";          
               fwrite($fp, $outputstring, strlen($outputstring));
               }
              flock($fp, LOCK_UN);
              fclose($fp);         
              
 ?>

<!DOCTYPE html>
<html lang="en">    
    <head>        
        <title>Order Fulfillment</title>
        <meta charset="utf-8">  
        <meta name="viewport" content="width=device-width initial-scale=1.0">
        <link href="autoparts.css" rel="stylesheet" type="text/css"> 
         <script src="alert/dist/alertify.min.js"></script>
	<link rel="stylesheet" href="alert/dist/alertify.core.css" />
	<link rel="stylesheet" href="alert/dist/alertify.default.css" id="toggleCSS" />             

       </head>
    <body>
         <div id="wrapper">    
        <header>
            <h1>Amplified Auto Parts</h1>
        </header>      
        <nav>
            <ul> 
              <li><a href="adminmenu.php">Company Portal Main Menu</a></li>
              <li><a href="adminreceiving.php">Receiving Console</a></li>        
            </ul>           
        </nav>
    <main>  
         <form action="adminwarehouse.php" method="post"> 
             
    <h3 style="text-align: center">Order complete.</h3> 
    
    <h2 style="text-align: center"> Order confirmation email will be sent to: <?php  echo $custemails ?></h2>
    
    
    <input type=submit id="btSubmit" name="confirm" value="Back to Warehouse" style="font-size: 2em;color: red;height:50px;width:75%">
    
    

  </form>

    </main> 
            
        <footer>
            
        Copyright &copy; 2022. Amplified Auto Parts, INC. All rights reserved. <br> 
     
        </footer> 
         </div>
    </body>
</html>


