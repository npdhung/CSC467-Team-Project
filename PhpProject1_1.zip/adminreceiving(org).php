<?php 
    $hostName = "blitz.cs.niu.edu:3306";
        $userName = "student";
        $password = "student";
        $databaseName = "csci467";
        $mysqli = new mysqli($hostName, $userName, $password, $databaseName);
        
        // Check connection
        if ($mysqli->connect_error) {
            die('Connect Error (' .
            $mysqli->connect_errno . ') '.
            $mysqli->connect_error);}
          
         // SQL query to select data from database
            $sql = " SELECT * FROM parts ORDER BY number LIMIT 141 OFFSET 0 ";
            $result = $mysqli->query($sql);
            $mysqli->close();

            $productDesc = array();
            $productPrice = array();
            $loop = 0;
                // LOOP TILL END OF DATA
                while($rows=$result->fetch_assoc())
                {
                 $productPartNo[$loop] = $rows['number'];   
                 $productPict[$loop] = $rows['pictureURL'];
                 $productDesc[$loop] = $rows['description'];
                 $productPrice[$loop] = $rows['price'];
                 $productWeight[$loop] = $rows['weight'];           
                 $loop++; 
                }          
 $productOH = array (); 
 //Read in the entire file. Each order becomes an element in the array
 $document_root = $_SERVER['DOCUMENT_ROOT'];              
 $delim = ","; 
 $status= file("$document_root/Auto Parts/database/productonhands.txt");
       $k = 0;
       $lines = explode($delim, $status[$k]);
       foreach ($lines as $val) {  
       $productOH[$k] = $val;
	   
       $k++;}         
 
    ?>

<!DOCTYPE html>
<html lang="en">    
    <head>        
        <title>Receiving Console</title>
        <meta charset="utf-8">  
        <meta name="viewport" content="width=device-width initial-scale=1.0">
        <link href="autoparts.css" rel="stylesheet" type="text/css"> 
        
    <style>
        body {margin:0;
        padding-top: 7.8em;}

        .navbar {
          overflow: hidden;
          background-color: black;
          position: fixed;
          top: 0;
          width: 100%;
          height: 120px; 
          margin-right: 2em;
        }

        .navbar a {
          float: left;
          display: block;
          color: #f2f2f2;
          text-align: center;
          padding: 14px 16px;
          text-decoration: none;
          font-size: 27px;
          margin-right: 2em;
        }

        .navbar a:hover {
          background: #ddd;
          color: black;
        }

        .main {
          padding: 16px;
          margin-top: 30px;
          height: 1500px; /* Used in this example to enable scrolling */
        }
        
        input{font-size: 18px;}
        
        </style>
              
        <script type='text/javascript' src='js/order.js'></script>  
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
    <script>
        $(document).ready(function(){
		//iterate through each textboxes and add keyup
		//handler to trigger sum event
		$(".txt").each(function() {
			$(this).keyup(function(){
				calculateSum();
                                calculateTotal();                            
			});
		});
	});

	function calculateSum() {
		var sum = 0;
                var u = 0;
                var addsum = 0;        
		//iterate through each textboxes and add the values
		$(".txt").each(function() {

			//add only if the value is number
			if(!isNaN(this.value) && this.value.length!==0) {       
                         const number1 = parseInt(document.getElementById("qty"+u).value); 
                         const number2 = parseInt(this.value);  
		         addsum = number1 + number2; 
                         document.getElementById("qty"+u).value = addsum; 
		         sum += parseFloat(this.value);
                        document.getElementById("entry"+u).value = "";
			}
                        u++;
		       }              
                      );
		
	        }
        
        function calculateTotal() {
                 var total = 0;
                 var counter = 0;            
        
		//iterate through each textboxes and add the values
		$(".txt2").each(function() {
                       
                        
			//add only if the value is number
			if(!isNaN(this.value) && this.value.length!==0) {             
                           for (let i = 0; i <= 140; i++) {
                                if(counter === i){
                                 document.getElementById(counter).value = parseFloat(this.value); 
                                total += parseFloat(this.value);}
                           } 
                           i=0;
			}                     
                     counter +=1;    
		});
                 var bt = document.getElementById('btSubmit');
                if (total >0) {
            bt.disabled = false;
        }
      }  
function myFunction() {
  var input, filter, table, tr, td,td2, i, txtValue, txtValue2;
  input = document.getElementById("myInput");
  filter = input.value.toUpperCase();
  table = document.getElementById("order-table");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[2];
    td2 = tr[i].getElementsByTagName("td")[0];
    if (td) {
      txtValue = td.textContent || td.innerText;
      txtValue2 = td2.textContent || td2.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1  || txtValue2.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
}


function choosepage2(i){  
   var onhand = [<?php echo '"'.implode('","', $productOH).'"' ?>]; 
  for (i = 0; i < 150; i++) {
  if( event.target.id === "btnundo"+i) {    
      document.getElementById("qty"+i).value = onhand[i];}
     }
}
     
        </script>  
    </head>
    <body>
        
         <div id="wrapper">   
        <header>
            <h1>Amplified Auto Parts</h1>
        </header>
  
             <main>
        <h2 style="color: blue; text-align: center"><font size="+4"> Amplified Auto Parts Inventory Management <font size="+0"></h2>
        <form action="adminreceiveconfirm.php" method="post">    
            
         <div class="navbar">
             <a href="adminmenu.php">Main Menu</a>
             <a href="adminwarehouse.php">Warehouse</a>
            <a><span>Filter results by part number or description</span></a>
            <a><span><input type="text" id="myInput" onkeyup="myFunction()" placeholder="Search"> </span></a>
<!--            <a><span>Total Items Added: </span></a>
            <a><span id="sum">0</span></a>          -->
            <input type=submit id="btSubmit" value="Save Quantities and Exit" style="font-size: 2em;color: red;height:50px;width:60%" disabled>        
          </div>       
            
        <table id="order-table"  class="table-info table">  
            
      <?php
      $counter = 0;
      for($i = 0; $i < 141; $i+=1 ){ ?>       
                          
    <tr style="background: lightgrey;">
      <td style="width: 150px; text-align: center;">Part: <?php  echo $productPartNo[$i] ?> </td>
      <td colspan ='1'><img src=<?php  echo $productPict[$i] ?> alt="" border='3' height='100' width='100' /></td>
      <td><font size="+1.5"><?php  echo $productDesc[$i] ?></td>
      <td><font size="+1.5"> <?php echo "$" .number_format($productPrice[$i], 2)."</>" ?> </font> each</td>
      <td><font size="+1.5">Weight: <?php  echo $productWeight[$i] ?></font></td>
      <td><font size="+2">In Stock: <center><input value= "<?php echo $productOH[$i] ?>"class="txt2" type="text"  id = '<?php echo "qty".$i?>' maxlength="5" size="5" margin-left: 35px disabled/> </center> </td>
      <td><font size="+2">Received Qty: <center><input class="txt" type="text" id = '<?php echo "entry".$i?>'  name="qty1" maxlength="5" size="5" margin-left: 35px/> </center> </td>
      <td><input type=button onClick="choosepage2(i)"id= '<?php echo "btnundo".$i?>' value="Undo" style="font-size:1.5em;color: red">  </td>     
    </tr>  
   
     <?php 
     $counter += 1;  
      } ?>        
    
    <tr style="background: #cccccc;">
      <td style="width: 150px; text-align: center;"></td>
      <td style="width: 200px; text-align: center;"></td> 
      <td style="width: 300px; text-align: center;"></td> 
      <td style="width: 100px; text-align: center;"></td>
      <td style="width: 100px; text-align: center;"></td> 
      <td style="width: 200px; text-align: center;"></td> 
      <td style="width: 200px; text-align: center;"></td> 
    </tr>  
      </table>        
    
        <input type="hidden" id="totalsum" name="totalsum">
        <input type="hidden" id="subtotalval" name="subtotalval"> 
        
        <input type="hidden" id="0" name="parts[]" value="0">
        <input type="hidden" id="1" name="parts[]" value="0">
        <input type="hidden" id="2" name="parts[]" value="0">
        <input type="hidden" id="3" name="parts[]" value="0">
        <input type="hidden" id="4" name="parts[]" value="0">
        <input type="hidden" id="5" name="parts[]" value="0">
        <input type="hidden" id="6" name="parts[]" value="0">
        <input type="hidden" id="7" name="parts[]" value="0">
        <input type="hidden" id="8" name="parts[]" value="0">
        <input type="hidden" id="9" name="parts[]" value="0">
        <input type="hidden" id="10" name="parts[]" value="0"> 
        <input type="hidden" id="11" name="parts[]" value="0">
        <input type="hidden" id="12" name="parts[]" value="0">
        <input type="hidden" id="13" name="parts[]" value="0">
        <input type="hidden" id="14" name="parts[]" value="0">
        <input type="hidden" id="15" name="parts[]" value="0">
        <input type="hidden" id="16" name="parts[]" value="0">
        <input type="hidden" id="17" name="parts[]" value="0">
        <input type="hidden" id="18" name="parts[]" value="0">
        <input type="hidden" id="19" name="parts[]" value="0">
        <input type="hidden" id="20" name="parts[]" value="0">   
        <input type="hidden" id="21" name="parts[]" value="0">
        <input type="hidden" id="22" name="parts[]" value="0">
        <input type="hidden" id="23" name="parts[]" value="0">
        <input type="hidden" id="24" name="parts[]" value="0">
        <input type="hidden" id="25" name="parts[]" value="0">
        <input type="hidden" id="26" name="parts[]" value="0">
        <input type="hidden" id="27" name="parts[]" value="0">
        <input type="hidden" id="28" name="parts[]" value="0">
        <input type="hidden" id="29" name="parts[]" value="0">
        <input type="hidden" id="30" name="parts[]" value="0">   
        <input type="hidden" id="31" name="parts[]" value="0">
        <input type="hidden" id="32" name="parts[]" value="0">
        <input type="hidden" id="33" name="parts[]" value="0">
        <input type="hidden" id="34" name="parts[]" value="0">
        <input type="hidden" id="35" name="parts[]" value="0">
        <input type="hidden" id="36" name="parts[]" value="0">
        <input type="hidden" id="37" name="parts[]" value="0">
        <input type="hidden" id="38" name="parts[]" value="0">
        <input type="hidden" id="39" name="parts[]" value="0">
        <input type="hidden" id="40" name="parts[]" value="0">
        <input type="hidden" id="41" name="parts[]" value="0">
        <input type="hidden" id="42" name="parts[]" value="0">
        <input type="hidden" id="43" name="parts[]" value="0">
        <input type="hidden" id="44" name="parts[]" value="0">
        <input type="hidden" id="45" name="parts[]" value="0">
        <input type="hidden" id="46" name="parts[]" value="0">
        <input type="hidden" id="47" name="parts[]" value="0">
        <input type="hidden" id="48" name="parts[]" value="0">
        <input type="hidden" id="49" name="parts[]" value="0">
        <input type="hidden" id="50" name="parts[]" value="0">      
        <input type="hidden" id="51" name="parts[]" value="0">
        <input type="hidden" id="52" name="parts[]" value="0">
        <input type="hidden" id="53" name="parts[]" value="0">
        <input type="hidden" id="54" name="parts[]" value="0">
        <input type="hidden" id="55" name="parts[]" value="0">
        <input type="hidden" id="56" name="parts[]" value="0">
        <input type="hidden" id="57" name="parts[]" value="0">
        <input type="hidden" id="58" name="parts[]" value="0">
        <input type="hidden" id="59" name="parts[]" value="0">
        <input type="hidden" id="60" name="parts[]" value="0">
        <input type="hidden" id="61" name="parts[]" value="0">
        <input type="hidden" id="62" name="parts[]" value="0">
        <input type="hidden" id="63" name="parts[]" value="0">
        <input type="hidden" id="64" name="parts[]" value="0">
        <input type="hidden" id="65" name="parts[]" value="0">
        <input type="hidden" id="66" name="parts[]" value="0">
        <input type="hidden" id="67" name="parts[]" value="0">
        <input type="hidden" id="68" name="parts[]" value="0">
        <input type="hidden" id="69" name="parts[]" value="0">
        <input type="hidden" id="70" name="parts[]" value="0"> 
        <input type="hidden" id="71" name="parts[]" value="0">
        <input type="hidden" id="72" name="parts[]" value="0">
        <input type="hidden" id="73" name="parts[]" value="0">
        <input type="hidden" id="74" name="parts[]" value="0">
        <input type="hidden" id="75" name="parts[]" value="0">
        <input type="hidden" id="76" name="parts[]" value="0">
        <input type="hidden" id="77" name="parts[]" value="0">
        <input type="hidden" id="78" name="parts[]" value="0">
        <input type="hidden" id="79" name="parts[]" value="0">
        <input type="hidden" id="80" name="parts[]" value="0">  
        <input type="hidden" id="81" name="parts[]" value="0">
        <input type="hidden" id="82" name="parts[]" value="0">
        <input type="hidden" id="83" name="parts[]" value="0">
        <input type="hidden" id="84" name="parts[]" value="0">
        <input type="hidden" id="85" name="parts[]" value="0">
        <input type="hidden" id="86" name="parts[]" value="0">
        <input type="hidden" id="87" name="parts[]" value="0">
        <input type="hidden" id="88" name="parts[]" value="0">
        <input type="hidden" id="89" name="parts[]" value="0">
        <input type="hidden" id="90" name="parts[]" value="0">  
        <input type="hidden" id="91" name="parts[]" value="0">
        <input type="hidden" id="92" name="parts[]" value="0">
        <input type="hidden" id="93" name="parts[]" value="0">
        <input type="hidden" id="94" name="parts[]" value="0">
        <input type="hidden" id="95" name="parts[]" value="0">
        <input type="hidden" id="96" name="parts[]" value="0">
        <input type="hidden" id="97" name="parts[]" value="0">
        <input type="hidden" id="98" name="parts[]" value="0">
        <input type="hidden" id="99" name="parts[]" value="0">
        <input type="hidden" id="100" name="parts[]" value="0">     
        <input type="hidden" id="101" name="parts[]" value="0">
        <input type="hidden" id="102" name="parts[]" value="0">
        <input type="hidden" id="103" name="parts[]" value="0">
        <input type="hidden" id="104" name="parts[]" value="0">
        <input type="hidden" id="105" name="parts[]" value="0">
        <input type="hidden" id="106" name="parts[]" value="0">
        <input type="hidden" id="107" name="parts[]" value="0">
        <input type="hidden" id="108" name="parts[]" value="0">
        <input type="hidden" id="109" name="parts[]" value="0">
        <input type="hidden" id="110" name="parts[]" value="0">     
        <input type="hidden" id="111" name="parts[]" value="0">
        <input type="hidden" id="112" name="parts[]" value="0">
        <input type="hidden" id="113" name="parts[]" value="0">
        <input type="hidden" id="114" name="parts[]" value="0">
        <input type="hidden" id="115" name="parts[]" value="0">
        <input type="hidden" id="116" name="parts[]" value="0">
        <input type="hidden" id="117" name="parts[]" value="0">
        <input type="hidden" id="118" name="parts[]" value="0">
        <input type="hidden" id="119" name="parts[]" value="0">
        <input type="hidden" id="120" name="parts[]" value="0">
        <input type="hidden" id="121" name="parts[]" value="0">
        <input type="hidden" id="122" name="parts[]" value="0">
        <input type="hidden" id="123" name="parts[]" value="0">
        <input type="hidden" id="124" name="parts[]" value="0">
        <input type="hidden" id="125" name="parts[]" value="0">
        <input type="hidden" id="126" name="parts[]" value="0">
        <input type="hidden" id="127" name="parts[]" value="0">
        <input type="hidden" id="128" name="parts[]" value="0">
        <input type="hidden" id="129" name="parts[]" value="0">
        <input type="hidden" id="130" name="parts[]" value="0">    
        <input type="hidden" id="131" name="parts[]" value="0">
        <input type="hidden" id="132" name="parts[]" value="0">
        <input type="hidden" id="133" name="parts[]" value="0">
        <input type="hidden" id="134" name="parts[]" value="0">
        <input type="hidden" id="135" name="parts[]" value="0">
        <input type="hidden" id="136" name="parts[]" value="0">
        <input type="hidden" id="137" name="parts[]" value="0">
        <input type="hidden" id="138" name="parts[]" value="0">
        <input type="hidden" id="139" name="parts[]" value="0">
        <input type="hidden" id="140" name="parts[]" value="0">
            
    </form>       
        </main>         
        <footer>        
        Copyright &copy; 2022. Amplified Auto Parts, INC. All rights reserved. <br> 
     
        </footer> 
         </div>  
    </body>
</html>



