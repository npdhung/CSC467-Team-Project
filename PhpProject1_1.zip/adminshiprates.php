
<?php


 $document_root = $_SERVER['DOCUMENT_ROOT'];              
 $delim = ","; 
 $status= file("$document_root/Auto Parts/database/shippingrates.txt");
 //$number_of_orders = count($status);
       $k = 0;
       $kk = 0;
       $lines = explode($delim, $status[0]);
       foreach ($lines as $val) {  
       ${'weightval'.$k} = sprintf("%03d", $val);
       $k++;}
       $lines = explode($delim, $status[1]);
       foreach ($lines as $val) {  
       ${'priceval'.$kk} = $val;
       $kk++;}
?>

<!DOCTYPE html>
<html lang="en">    
    <head>        
        <title>Shipping Rates Console</title>
        <meta charset="utf-8">  
        <meta name="viewport" content="width=device-width initial-scale=1.0">
        <link href="autoparts.css" rel="stylesheet" type="text/css"> 
      <style> 
          
          #save_button1  {display: none; } #save_button2  {display: none; } #save_button3  {display: none; }
          #save_button4  {display: none; } #save_button5  {display: none; } #save_button6  {display: none; }
          #save_button7  {display: none; } #save_button8  {display: none; } #save_button9  {display: none; }
          #save_button10  {display: none; } #save_button11  {display: none; } #save_button12  {display: none; }
          #save_button13  {display: none; }#save_button14  {display: none; } #save_button15  {display: none; }
          #save_button16  {display: none;} #save_button0  {display: none;}
          
   
      </style>
            
</head>
    <body>
         <div id="wrapper">    
        <header>
            <h1>Amplified Auto Parts</h1>
        </header>
        
        <nav>
            <ul> 
             <li><a href="adminmenu.php">Company Portal Main Menu</a></li>
             <li><a href="adminorders.php">Customer Orders</a></li>
            </ul>           
        </nav>
    <main>      
                             
       <h3 style="color: blue; text-align: center"><font size="+3"> Shipping Rates Console <font size="+0"></h3>
       <h3 style="text-align: center"> Maximum Shipping Pounds = 100,000 lbs</h3>
       
      <form action="adminshiprateconfirm.php" method="post"> 
          
        <table id="data_table" style="margin-left: auto; margin-right: auto">              
        <tr style="background: #cccccc;">
          <th style="width: 150px; text-align: center;">From (lbs.)</th> 
          <th style="width: 150px; text-align: center;">To (lbs.)</th> 
          <th style="width: 150px; text-align: center;">Price ($)</th> 
          <th style="width: 70px; text-align: right;"></th> 
          <th style="width: 70px; text-align: right;"></th> 
        </tr> 
        
         <tr id="row0">
          <td id="bracket_row0" style="width: 150px; text-align: center;">000</td>
          <td id="bracket2_row0" style="width: 150px; text-align: center;"><?php echo$weightval0?></td> 
          <td id="price_row0" style="width: 150px; text-align: center">Free Shipping</td> 
          <td id="blank_row0" style="width: 70px; text-align: right;"></td> 
          <td id="blank2_row0" style="width: 70px; text-align: right;"></td> 
          </tr>  
          
          <?php 
          for($a=0;$a < $k-1; $a++){?>
          
        </tr>
         <tr id=<?php echo "row".$a?>>
          <td id=<?php echo "name_row".$a?> style="width: 150px; text-align: center;"><?php echo${'weightval'.$a}?></td>  
          <td id=<?php echo "name2_row".$a?> style="width: 150px; text-align: center;"><?php echo${'weightval'.$a+1}?></td> 
          <td id=<?php echo "country_row".$a?> style="width: 150px; text-align: center;"><?php echo${'priceval'.$a}?></td> 
          <td>
        <input type="button" value="Delete" class="delete" onclick="delete_row('<?php echo $a?>')">    
        </td>
        
        <td>
        <input type="button" id='<?php echo "edit_button".$a?>'  value="Edit" class="edit" onclick="edit_row('<?php echo $a?>')">
        <input type="button" id="<?php echo "save_button".$a?>" value="Save" class="save" onclick="save_row('<?php echo $a?>')">       
        </td>
        
        </tr>    
         <?php } ?>
          
         </table>   
          <br>    
       <table style="margin-left: auto; margin-right: auto"> 
      <tr>
      <td style="width: 200px; text-align: left">Weight<input type="text" id="new_name" maxlength="3" onblur="while(this.value.length<parseInt(this.getAttribute('maxlength')))this.value='0'+this.value;" /></td>
      <td style="text-align: left"><input type="hidden" id="new_name2" maxlength="3" onblur="while(this.value.length<parseInt(this.getAttribute('maxlength')))this.value='0'+this.value;" /></td>
      <td style="width: 200px; text-align: left">Cost<input type="text" id="new_country"></td>
      <td style="width: 175px; text-align: left"><input type="button" class="add" onclick="sortTable();" value="Add New Bracket "></td>    
      </tr>       
      </table>             
          <br>       
    <input type=submit id="btSubmit" value="Confirm all changes and exit" style="font-size: 2em;color: red;height:50px;width:45%; margin-left:auto; margin-right: auto;">       
     <p id="info"></p>
    <script>
function edit_row(no)
{
 document.getElementById("edit_button"+no).style.display="none";
 document.getElementById("save_button"+no).style.display="block";
	
 var name=document.getElementById("name_row"+no);
 var name2=document.getElementById("name2_row"+no);
 var country=document.getElementById("country_row"+no);
	
 var name_data=name.innerHTML;
 var name2_data=name2.innerHTML;
 var country_data=country.innerHTML;
	
 name.innerHTML="<input type='text' id='name_text"+no+"' value='"+name_data+"'>";
 name2.innerHTML="<input type='text' id='name2_text"+no+"' value='"+name2_data+"'>";
 country.innerHTML="<input type='text' id='country_text"+no+"' value='"+country_data+"'>";
}

function save_row(no)
{
 var name_val=document.getElementById("name_text"+no).value;
 var name_val2=document.getElementById("name2_text"+no).value;
 var country_val=document.getElementById("country_text"+no).value;

 document.getElementById("name_row"+no).innerHTML=name_val;
 document.getElementById("name2_row"+no).innerHTML=name_val2;
 document.getElementById("country_row"+no).innerHTML=country_val;

 document.getElementById("edit_button"+no).style.display="block";
 document.getElementById("save_button"+no).style.display="none";
}

function delete_row(no){
            var u = no;
            var name=document.getElementById("name_row"+u);
            var country=document.getElementById("country_row"+u);
            var name_data=name.innerHTML;
            var country_data=country.innerHTML;
            name.innerHTML="<input type='text' id='name_text"+u+"' value='"+name_data+"'>";  
            country.innerHTML="<input type='text' id='country_text"+u+"' value='"+country_data+"'>";
            
            var txtbox1 = document.getElementById("name_text"+u);
            var txtbox2 = document.getElementById("TextWeightDel");
            var old3  = txtbox2.value;
            var txtbox3 = document.getElementById("country_text"+u);           
            var txtbox4 = document.getElementById("TextPriceDel");
            var old4  =  txtbox4.value;
            txtbox2.value = old3 + txtbox1.value +","; 
            txtbox4.value = old4 +txtbox3.value+ ",";
            
            
 document.getElementById("row"+no+"").outerHTML="";
 
 document.getElementById('info').innerHTML = "";
        var myTab = document.getElementById('data_table');
        no++;
        var objCells = myTab.rows.item(no).cells;
        no++;
        var objectCells = myTab.rows.item(no).cells;
        objCells.item(1).innerHTML= objectCells.item(0).innerHTML;              
        }
  
function sortTable() {
            var txtbox1 = document.getElementById("new_name");
            var txtbox2 = document.getElementById("TextWeightAdd");
            var old  = txtbox2.value;
            var txtbox3 = document.getElementById("new_country");             
            var txtbox4 = document.getElementById("TextPriceAdd");
            var old2  =  txtbox4.value;
            txtbox2.value = old + txtbox1.value +","; 
            txtbox4.value = old2 +txtbox3.value+ ",";
  
    
 var new_name=document.getElementById("new_name").value;
 var new_name2=document.getElementById("new_name2").value;
 var new_country=document.getElementById("new_country").value;
	
 var tables=document.getElementById("data_table");
 var table_len=(tables.rows.length)-0;
 var row = tables.insertRow(table_len).outerHTML="<tr id='row"+table_len+"'><td id='name_row"+table_len+"'>"+new_name+"</td><td id='name2_row"+table_len+"'>"+new_name2+"</td><td id='country_row"+table_len+"'>"+new_country+"</td><td><input type='button' value='Delete' class='delete' onclick='delete_row("+table_len+")'></td><td><input type='button' id='edit_button"+table_len+"' value='Edit' class='edit' onclick='edit_row("+table_len+")'> <input type='button' id='save_button"+table_len+"' value='Save' class='save' onclick='save_row("+table_len+")'></td></tr>";

 document.getElementById("new_name").value="";
 document.getElementById("new_name2").value="";
 document.getElementById("new_country").value="";
 
  var table, rows, switching, i, x, y, z, zz,zzz, shouldSwitch;
  table = document.getElementById("data_table");
  switching = true;
  /*Make a loop that will continue until no switching has been done:*/
  while (switching) {
    //start by saying: no switching is done:
    switching = false;
    rows = table.getElementsByTagName("TR");
    /*Loop through all table rows (except the first, which contains table headers):*/
    for (i = 1; i < (rows.length - 1); i++) {
      //start by saying there should be no switching:
      shouldSwitch = false;
      /*Get the two elements you want to compare,one from current row and one from the next:*/
      x = rows[i].getElementsByTagName("TD")[0];
      y = rows[i + 1].getElementsByTagName("TD")[0];
      z = rows[i].getElementsByTagName("TD")[1];
      zz = rows[i + 1].getElementsByTagName("TD")[1];
      zzz = rows[i - 1].getElementsByTagName("TD")[1];
      //check if the two rows should switch place:
      if (x.innerHTML.toLowerCase() > y.innerHTML.toLowerCase()) {
        //if so, mark as a switch and break the loop:
        shouldSwitch= true;
        zz.innerHTML=zzz.innerHTML;
        //zzz.innerHTML=y.innerHTML;
        break;
      }
    }
    if (shouldSwitch) {
      /*If a switch has been marked, make the switch
      and mark that a switch has been done:*/
      rows[i].parentNode.insertBefore(rows[i + 1], rows[i]);
      switching = true;
    }
  }
  
 
  for (i = 1; i < (rows.length - 1); i++) {
      x = rows[i].getElementsByTagName("TD")[0];
      y = rows[i + 1].getElementsByTagName("TD")[0];
      z = rows[i].getElementsByTagName("TD")[1];
      zz = rows[i + 1].getElementsByTagName("TD")[1];
      zzz = rows[i - 1].getElementsByTagName("TD")[1];
      //check if the two rows should switch place:
      if (z.innerHTML.toLowerCase() === zz.innerHTML.toLowerCase()) {
        //if so, mark as a switch and break the loop:
        //zz.innerHTML=zzz.innerHTML;
        z.innerHTML=y.innerHTML;
        break;
      }
    }
 
 for (i = 1; i < (rows.length - 1); i++) {
      x = rows[i].getElementsByTagName("TD")[0];
      y = rows[i + 1].getElementsByTagName("TD")[0];
      z = rows[i].getElementsByTagName("TD")[1];
      zz = rows[i + 1].getElementsByTagName("TD")[1];
      zzz = rows[i - 1].getElementsByTagName("TD")[1];
      //check if the two rows should switch place:
       if (z.innerHTML.toLowerCase() === zz.innerHTML.toLowerCase()) {
        //if so, mark as a switch and break the loop:
        z.innerHTML=y.innerHTML;
        break;}
     if (z.innerHTML.toLowerCase() === "") {
     }
      zz.innerHTML = '100000';
      z.innerHTML=y.innerHTML;
    } 
}
   
</script>


    
 <input type="hidden" id="TextWeightAdd" name="TextWeightAdd" />
  <input type="hidden" id="TextPriceAdd" name="TextPriceAdd" />

  <input type="hidden" id="TextWeightDel" name="TextWeightDel" />
  <input type="hidden" id="TextPriceDel" name="TextPriceDel" />
 
  
      </form>
     </main> 
            
        <footer>
            
        Copyright &copy; 2022. Amplified Auto Parts, INC. All rights reserved. <br> 
     
        </footer> 
         </div>
    </body>
</html>


