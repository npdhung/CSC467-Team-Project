<?php require_once("conn.php"); 

if(isset($_POST['submit']))
{
    $capture_field_vals ="";
    foreach($_POST["msgrecipient"] as $key => $text_field)
    {
        //INSERT INTO `inv_detail` (inv_id,Num,descript,inv_Qty) 
		//SELECT inv.inv_ID, Parts.number,Parts.description,"10" AS inv_Qty
        //FROM invoice AS inv INNER JOIN parts AS Parts
		//WHERE inv.inv_ID ="123432" AND Parts.number="5";
        
        
        echo "Key: $key; Value: $text_field<br />\n";

        echo "<br>";

    }
        foreach($_POST["enquiry"] as $key => $text_field2)
        {
        echo "Key: $key; Value: $text_field2<br />\n";

        echo "<br>";
        }
}

    ?>
<!DOCTYPE html>
<html>
<head>        
        <title>Receiving Console</title>
        <meta charset="utf-8">  
        <meta name="viewport" content="width=device-width initial-scale=1.0">
        <link href="autoparts.css" rel="stylesheet" type="text/css"> 
        
    <style>
        body {margin:0;
        padding-top: 7.8em;}

        .navbar {
          overflow: hidden;
          background-color: black;
          position: fixed;
          top: 0;
          width: 100%;
          height: 120px; 
          margin-right: 2em;
        }

        .navbar a {
          float: left;
          display: block;
          color: #f2f2f2;
          text-align: center;
          padding: 14px 16px;
          text-decoration: none;
          font-size: 27px;
          margin-right: 2em;
        }

        .navbar a:hover {
          background: #ddd;
          color: black;
        }

        .main {
          padding: 16px;
          margin-top: 30px;
          height: 1500px; /* Used in this example to enable scrolling */
        }
        
        input{font-size: 18px;}
		.inputbox {		
				max-width: 800px;
				margin: auto;
				padding: 30px;
				border: 1px solid red;
				box-shadow: 0 0 10px rgba(0, 0, 0, 0.15);
				font-size: 16px;
				line-height: 24px;
				font-family: 'Helvetica Neue', 'Helvetica', Helvetica, Arial, sans-serif;
				color: #555;
		}
		.inputbox table {
				width: 100%;
				line-height: inherit;
				text-align: left;
			}
		label {
			display: inline-block;
			width: 100px;
			text-align: middle;
			}​
        </style>
        </script>
<meta charset="UTF-8">
<title>Application</title>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script>
$(function () {
    $('#btnAdd').click(function () {
        var num = $('.clonedInput').length, // how many "duplicatable" input fields we currently have
            newNum = new Number(num + 1), // the numeric ID of the new input field being added
            newElem = $('#testingDiv' + num).clone().attr('id', 'testingDiv' + newNum).fadeIn('slow'); // create the new element via clone(), and manipulate it's ID using newNum value

        newElem.find('.test-select').attr('id', 'ID' + newNum + '_select').attr('name', 'ID' + newNum + '_select').val('');
        newElem.find('.test-textarea').val('');
         // insert the new element after the last "duplicatable" input field
        $('#testingDiv' + num).after(newElem);
        // enable the "remove" button
        $('#btnDel').attr('disabled', false);
        // right now you can only add 5 sections. change '5' below to the max number of times the form can be duplicated
        if (newNum == 5) $('#btnAdd').attr('disabled', true).prop('value', "You've reached the limit");
    });

    $('#btnDel').click(function () {
        // confirmation
        if (confirm("Are you sure you wish to remove this section of the form? Any information it contains will be lost!")) {
            var num = $('.clonedInput').length;
            // how many "duplicatable" input fields we currently have
            $('#testingDiv' + num).slideUp('slow', function () {
                $(this).remove();
                // if only one element remains, disable the "remove" button
                if (num - 1 === 1) $('#btnDel').attr('disabled', true);
                // enable the "add" button
                $('#btnAdd').attr('disabled', false).prop('value', "[ + ] add to this form");
            });
        }
        return false;
        // remove the last element

        // enable the "add" button
        $('#btnAdd').attr('disabled', false);
    });

    $('#btnDel').attr('disabled', true);
});
</script>
</head>
<body>
 <body>
        
         <div id="wrapper">   
        <header>
            <h1>Amplified Auto Parts</h1>
        </header>
  
		<main>
        <h2 style="color: blue; text-align: center"><font size="+4"> Receiving Invoice Management <font size="+0"></h2>
        <h2> INVOICE FORM </h2>
		<pre>
<div class="inputbox">
		
	<form action="#" method="post">
	<table class="inputbox table">
		<tr>
			<td style="width:0px">
				<div class="block">
				<label style = "width: 125px"> invoice number </label>
				<input type="number" style="width: 125px" id=invoice_ID value= "invoice number">
				</div>
			</td>
			<td style="width:300px text-align:center"> 
				<div> 
					<label> Company name: </lable><br>
					<input type="text" style= "width: 150px text-align:center" id=distro_name value="">
				</div>
			
			</td>
		</tr>
    <!--
    ########################################## -->
    <!-- START CLONED SECTION -->
    <!-- ########################################## -->
	<tr>
		<td>
		<div id="testingDiv1" class="clonedInput">
			<div>
			<label> product:</label>
			</div>
			<select name="msgrecipient[]" id="select">
				<option style= "width=200px" value=""></option>
				<?php
					require_once("conn.php");
					$sql="SELECT description FROM parts";
					$records=mysqli_query($conn,$sql);
					while($row=mysqli_fetch_assoc($records)){
					$name=$row['description'];
					echo "<option value='$name'>".$name."</option>";
					}

					?>

				</select>
			<label> Quanlity</label>
			<input type= "number" style="width=0px" id ="qty" value ="quanlity">
			<label> Comment</label>
			<textarea id="textarea" name="enquiry[]" class="test-textarea"></textarea>
		
    </div>
    <!--/clonedInput-->
    <!-- ########################################## -->
    <!-- END CLONED SECTION -->
    <!-- ########################################## -->
    <!-- ADD - DELETE BUTTONS -->
    <div id="add-del-buttons">
        <input type="button" id="btnAdd" value="[ + ] add to this form">
        <input type="button" id="btnDel" value="[ - ] remove the section above">
    </div>
		</td>
	</tr>
	</table>
    <!-- /ADD - DELETE BUTTONS -->
    <input type="submit" name="submit"class="button button-block" value="Submit"/>
</form>
</div>
<form action="adminreceiveconfirm.php" method="post">    
            
         <div class="navbar">
             <a href="adminmenu.php">Main Menu</a>
             <a href="adminwarehouse.php">Warehouse</a>
            <a><span>Filter results by part number or description</span></a>
            <a><span><input type="text" id="myInput" onkeyup="myFunction()" placeholder="Search"> </span></a>
<!--            <a><span>Total Items Added: </span></a>
            <a><span id="sum">0</span></a>          -->
                 
          </div>
		<div class='left'>  
  
		</form>
		</div>
		
        </main>         
        <footer>        
        Copyright &copy; 2022. Amplified Auto Parts, INC. All rights reserved. <br> 
     
        </footer> 
         </div>  
    </body>

</body>
</html>