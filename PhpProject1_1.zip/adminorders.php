<?php
// create short variable name
$document_root = $_SERVER['DOCUMENT_ROOT'];
date_default_timezone_set('America/Chicago');
$date = date('m/d/Y h:i:s a', time());
$tomorrow = date("m/d/Y", strtotime("+1 day"));      
       
?>

<!DOCTYPE html>
<html lang="en">    
    <head>        
        <title>Customer Orders</title>
        <meta charset="utf-8">  
        <meta name="viewport" content="width=device-width initial-scale=1.0">
        <link href="autoparts.css" rel="stylesheet" type="text/css"> 
         <style>
* {box-sizing: border-box;}

#myInput {
  background-image: url('/css/searchicon.png');
  background-position: 10px 10px;
  float: right;
  background-repeat: no-repeat;
  width: 20%;
  font-size: 16px;
  padding: 12px 20px 12px 40px;
  border: 1px solid #ddd;
  margin-bottom: 12px;
}

label {
  width:150px;
  display: inline-block;
}

 * { box-sizing:border-box; }

td:nth-child(even) { background-color: whitesmoke; }

tr:nth-child(even) { background-color: beige; }

.multirow td { display: inline-block !important; width: auto; border: 1px solid #eee; }

.multirow td:nth-child(1) { width: 100%; }
.multirow td:nth-child(2) { width: 100%; }
.multirow td:nth-child(3) { width: 18%; }
.multirow td:nth-child(4) { width: 18%; } 
.multirow td:nth-child(5) { width: 20%; } 
.multirow td:nth-child(6) { width: 20%; }
.multirow td:nth-child(7) { width: 20%; }
.multirow td:nth-child(8) { width: 20%; }
.multirow td:nth-child(9) { width: 15%; }
.multirow td:nth-child(10) { width: 10%; }
.multirow td:nth-child(11) { width: 10%; }
.multirow td:nth-child(12) { width: 15%; }
.multirow td:nth-child(13) { width: 15%; }
.multirow td:nth-child(14) { width: 15%; }
.multirow td:nth-child(15) { width: 40%; }
.multirow td:nth-child(16) { width: 60%; }
.multirow td:nth-child(17) { width: 40%; }
.multirow td:nth-child(17) { width: 60%; }
.multirow td:nth-child(18) { width: 40%; }
.multirow td:nth-child(19) { width: 60%; }
.multirow td:nth-child(20) { width: 40%; }
.multirow td:nth-child(21) { width: 60%; }
.multirow td:nth-child(22) { width: 40%; }
.multirow td:nth-child(23) { width: 60%; }
.multirow td:nth-child(24) { width: 40%; }
.multirow td:nth-child(25) { width: 60%; }
.multirow td:nth-child(26) { width: 40%; }
.multirow td:nth-child(27) { width: 60%; }
.multirow td:nth-child(28) { width: 40%; }
.multirow td:nth-child(29) { width: 60%; }
.multirow td:nth-child(30) { width: 40%; }
.multirow td:nth-child(31) { width: 60%; }
.multirow td:nth-child(32) { width: 40%; }
.multirow td:nth-child(33) { width: 60%; }
.multirow td:nth-child(34) { width: 40%; }
.multirow td:nth-child(35) { width: 60%; }
.multirow td:nth-child(36) { width: 40%; }
.multirow td:nth-child(37) { width: 60%; }
.multirow td:nth-child(38) { width: 40%; }
.multirow td:nth-child(39) { width: 60%; }
.multirow td:nth-child(40) { width: 40%; }
.multirow td:nth-child(41) { width: 60%; }

#ddList{
 width:180px;
 height: 30px;}

#prizesearch{
 margin-left: 210px;}

button{
 margin-left: 210px;}

.container {
/*    position: fixed;*/
    left: 50px;
    padding: 0;
    margin-right: 20px;
    background-color: white;}

.left-element {
    background: none;
    display: inline-block;
    float: left;
    margin-right: 4em;}

.right-element {
    background: white;
    display: inline-block;
    float: left;
    margin-right: 15.4em;
}



</style>   
</head>
    <body>
         <div id="wrapper">    
        <header>
            <h1>Amplified Auto Parts</h1>
        </header>      
        <nav>
            <ul> 
              <li><a href="adminmenu.php">Company Portal Main Menu</a></li>
              <li><a href="adminshiprates.php">Shipping Rates Console</a></li>        
            </ul>           
        </nav>
    <main>                          
    <h3 style="text-align: center">Customer Orders Report:  <?php echo $date?></h3>
    <form id="newForm">
       <?php    
        //Read in the entire file. Each order becomes an element in the array
        $delimiter = "^"; 
        $orders= file("$document_root/Auto Parts/database/orders.txt");
        // count the number of orders in the array
        $number_of_orders = count($orders);
        if ($number_of_orders == 0) {
        echo "<p><strong>No orders pending.<br />
        Please try again later.</strong></p>";
        } 
        else{?>
    <hr>
    
           <div class="container">
    <div class="left-element">
         
    </div>
    <div class="right-element">
        <br><br><br>
        <select id="ddList" onClick="onSelect()">
        <option value="0">select</option>
        <option value="open">open</option>
        <option value="filled">filled</option>
        </select>
    </div>
                 <div class="right-element">
        <br>
        <label>Prize From: </label>
            <input id="prize-start" type="text" value="0"></input>
            <label>To</label>  
            <input id="prize-stop" type="text" value="99999"></input>
            <button type="button" id="prizesearch" onclick="searchPrizeAlternative()">Search By Prize</button>
            <br><br>
    </div>
</div>
       
    <br>
            <label>From 12:00AM </label>
            <input id="date-start" type="text" value="01/01/2020"></input>
            <label>To 12:00AM </label>  
            <input id="date-stop" type="text" value="<?php echo$tomorrow?>"></input>
            <button type="button" id="datesearch" onclick="searchDateAlternative()">Search By Date</button>
            <br><br>
    
   <table class='multirow' id="myTable" border="1" width="100%">          
    <?php 
    $c = 0;
    $r = 1;
    $label = "";
    for ($i=0; $i<$number_of_orders; $i+=1) {
       $line = explode($delimiter, $orders[$i]);?>
       
       <tr class="item">
         <td style="background-color: darkorchid">id: <?php echo $r ?> </td>   
         <?php foreach ($line as $value) {
             if($c == 0){
                 $label = "Status - " ;}
             if($c == 1){
                 $label = "" ;}
             if($c == 2){
                 $label = "Auth No. - " ;}
             if($c == 3){
                 $label = "Order No. - " ;}
             if($c == 4){
                $label = "Name - " ;}
             if($c == 5){
                 $label = "Email - " ;}
             if($c == 6){
                 $label = "" ;}
             if($c == 7){
                 $label = "" ;} 
             if($c == 10){
                  $label = "Weight:  " ;}
             if($c == 11){
                 $label = "Ship:  $" ;}     
             if($c == 12){
                 $label = "Total:  $" ;}
             if($c == 13){
                 $label = "";
                 ?>                              
                  <td style="background-color: grey">Quantity</td>
                  <td style="background-color: grey">item</td>                          
             <?php  }      
             ?> <td> <?php echo $label ?><?php echo $value ?> </td>
         <?php 
         $c ++;
         } 
         $c = 0;?> 
       </tr> 
      
     <?php 
       $r++;
         } ?>      
   </table>             
        <?php }?>    

<script>
function searchDateAlternative() {
  // get the values and convert to date
  const input_startDate = new Date(document.getElementById("date-start").value);
  const input_stopDate = new Date(document.getElementById("date-stop").value);

  // only process table body rows, ignoring footer/headers
  const tr = document.querySelectorAll("#myTable tbody tr");

  for (let i = 0; i < tr.length; i++) {
    // ensure we have a relevant td
    let td = tr[i].getElementsByTagName("td");
    if (!td || !td[2]) continue;

    // you need to get the text and convert to date
    let td_date = new Date(td[2].textContent);

    // now you can compare dates correctly
    if (td_date) {
      if (td_date >= input_startDate && td_date <= input_stopDate) {
        // show the row by setting the display property
        tr[i].style.display = 'table-row;';
      } else {
        // hide the row by setting the display property
        tr[i].style.display = 'none';
      }
    }

  }
}

var prevIndex = "";

    function onSelect() {
        var currIndex = document.getElementById("ddList").selectedIndex;
        if (currIndex > 0) {
            if (prevIndex !== currIndex) {
                var input, filter, table, tr, td, i, txtValue;
  input = document.getElementById("ddList");
  filter = input.value.toUpperCase();
  table = document.getElementById("myTable");
  tr = table.getElementsByTagName("tr");
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName("td")[1];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }       
  }
                prevIndex = currIndex;
            }
            else {
                prevIndex = "";
            }
        }
        
    }
    
  function searchPrizeAlternative() {
  }
   
    

</script>
    </form>
                 </main> 
            
        <footer>
            
        Copyright &copy; 2022. Amplified Auto Parts, INC. All rights reserved. <br> 
     
        </footer> 
         </div>
    </body>
</html>