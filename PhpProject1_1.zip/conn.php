<?php
		$hostName = "localhost:3306";
		$userName = "root";
		$password = "";
		$databaseName = "csci467";
		try{
			//$dsn = "mysql:host = localhost:3306, dbname=csci467";
			$conn = mysqli_connect("localhost:3306","root","","csci467");
			//$sql ="SELECT `description` FROM parts";
			//$res= mysqli_query($conn,$sql);
			//$result= mysql_query("SELECT * FROM parts");
			
			
			//echo '<option value="'.$getID.'">'.$getName.'</option>';
			
		} catch(PDOException $e){
			echo 'Caught exception:'.$e->getMessage();
		}
		
?>