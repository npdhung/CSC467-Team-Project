INSERT INTO Associates 
(Id, FirstName, LastName, UserName, Password, Role, 
StreetAddress, City, State, Zip, Email, AccumulatedCommission) 
VALUES
(1, 'Charles', 'Gilbert', 'cgil', 'password', 'sales',
'2629 Franklin Street', 'Tuskegee', 'AL', 36083, 'CharlesVGilbert@teleworm.us', 0.0);

INSERT INTO Associates 
(FirstName, LastName, UserName, Password, Role, 
StreetAddress, City, State, Zip, Email, AccumulatedCommission) 
VALUES
('Jessie', 'Powell', 'jpow', 'password', 'sales',
'2676 Beeghley Street', 'Huntsville', 'AL', 35816, 'ManuelJPowell@armyspy.com', 0.0);

INSERT INTO Associates 
(FirstName, LastName, UserName, Password, Role, 
StreetAddress, City, State, Zip, Email, AccumulatedCommission) 
VALUES
('Isis', 'Rodriguez', 'irod', 'password', 'sales',
'645 Franklin Street', 'Montgomery', 'AL', 36104, 'IsisJRodriquez@rhyta.com', 0.0);

INSERT INTO Associates 
(FirstName, LastName, UserName, Password, Role, 
StreetAddress, City, State, Zip, Email, AccumulatedCommission) 
VALUES
('Janet', 'Whitehurst', 'jwhi', 'password', 'admin',
'4661 Turnpike Drive', 'Huntsville', 'AL', 35816, 'JanetAWhitehurst@dayrep.com', 0.0);

INSERT INTO Associates 
(FirstName, LastName, UserName, Password, Role, 
StreetAddress, City, State, Zip, Email, AccumulatedCommission) 
VALUES
('Peter', 'Glessner', 'pgle', 'password', 'admin',
'4723 Joyce Street', 'Silverhill', 'AL', 36576, 'PeterTGlessner@armyspy.com', 0.0);

INSERT INTO Associates 
(FirstName, LastName, UserName, Password, Role, 
StreetAddress, City, State, Zip, Email, AccumulatedCommission) 
VALUES
('Brian', 'Bay', 'bbay', 'password', 'admin',
'3974 George Avenue', 'Flomaton', 'AL', 36441, 'BrianCBay@rhyta.com', 0.0);

INSERT INTO Associates 
(FirstName, LastName, UserName, Password, Role, 
StreetAddress, City, State, Zip, Email, AccumulatedCommission) 
VALUES
('Kim', 'Conners', 'kcon', 'password', 'manag',
'2306 Fleming Street', 'Montgomery', 'AL', 36104, 'KimHConners@jourrapide.com', 0.0);

INSERT INTO Associates 
(FirstName, LastName, UserName, Password, Role, 
StreetAddress, City, State, Zip, Email, AccumulatedCommission) 
VALUES
('Gloria', 'Johnson', 'gjon', 'password', 'manag',
'3275 Ferry Street', 'Enterprise', 'AL', 36330, 'GloriaJJohnson@teleworm.us', 0.0);

INSERT INTO Associates 
(FirstName, LastName, UserName, Password, Role, 
StreetAddress, City, State, Zip, Email, AccumulatedCommission) 
VALUES
('Richard', 'Warner', 'rwar', 'password', 'manag',
'1748 Willow Greene Drive', 'Montgomery', 'AL', 36104, 'RichardAWarner@rhyta.com', 0.0);

INSERT INTO Quotes 
(Id, Status, DiscountPercentage,
DiscountAmount, ProcessingDate, AssociateId) 
VALUES
(1, "in-progress", null, null, null, 1);

INSERT INTO Quotes 
(Status, DiscountPercentage,
DiscountAmount, ProcessingDate, AssociateId) 
VALUES
("finalized", null, null, null, 1);

INSERT INTO Quotes 
(Status, DiscountPercentage,
DiscountAmount, ProcessingDate, AssociateId) 
VALUES
("sanctioned", 11, null, '2020/01/06 15:55:15', 1);

INSERT INTO LineItems
(QuoteId, ItemNumber, ItemDescription, ItemPrice)
VALUES
(3, 1, "luftmensch", 7365);

INSERT INTO LineItems
(QuoteId, ItemNumber, ItemDescription, ItemPrice)
VALUES
(3, 2, "zeg", 57.62);

INSERT INTO LineItems
(QuoteId, ItemNumber, ItemDescription, ItemPrice)
VALUES
(3, 3, "litost", 65);

INSERT INTO LineItems
(QuoteId, ItemNumber, ItemDescription, ItemPrice)
VALUES
(3, 4, "bilita mpash", 35);

INSERT INTO LineItems
(QuoteId, ItemNumber, ItemDescription, ItemPrice)
VALUES
(2, 1, "cavoli riscaldati", 75);

INSERT INTO LineItems
(QuoteId, ItemNumber, ItemDescription, ItemPrice)
VALUES
(1, 1, "hygge", 99700);


INSERT INTO QuoteNotes
(QuoteId, NoteNumber, Text)
VALUES
(1, 1, "excelsior!");

INSERT INTO QuoteNotes
(QuoteId, NoteNumber, Text)
VALUES
(1, 2, "no me digas");


INSERT INTO QuoteNotes
(QuoteId, NoteNumber, Text)
VALUES
(1, 3, "sheeball");

INSERT INTO QuoteNotes
(QuoteId, NoteNumber, Text)
VALUES
(2, 1, "uffa");

INSERT INTO QuoteNotes
(QuoteId, NoteNumber, Text)
VALUES
(3, 1, "oh mein gott");