<?php
    $dbname = "mysql:host=courses;dbname=zxxxxxxx";
    $user = "zxxxxxxx";
    $pass = "YYYYMmmDD";
?>
