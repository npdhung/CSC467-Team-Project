# CSCI_466_GROUP_22
Web Based Store Group Project

## Sample user accounts to test website with ##
#### ------------------------
### Jared Wilkinson --- ADMIN PERMS ###
#### USERID: 1
#### PASS:   boley
#### ------------------------

### Tim Lenny ###
#### USERID: 2
#### PASS:   LennyFl0rida
#### ------------------------

### Agatha Vilakay ###
#### USERID: 3
#### PASS:   agath123
#### ------------------------

### Suzannah McReallyLongnameBecauseLongName ###
#### USERID: 4
#### PASS:   123pass
#### ------------------------

### Gary Yunmer ###
#### USERID: 5
#### PASS:   SomeSomewhatLongPassword22
#### ------------------------
