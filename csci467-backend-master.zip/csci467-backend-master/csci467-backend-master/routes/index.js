// AUTHORS: Jeff Ditusa, Ben Kluga, Aviraj Parmar
// PURPOSE: To route requests from the frontend, properly and securely to the database

var express = require('express');
var router = express.Router();
const mariadb = require('mariadb');
var mysql = require('mysql');
var axios = require('axios');
var nodemailer = require('nodemailer');

//Jeff's Global Variables used for passing information to functions below
var globalOrderNum
var globalCustomerId 
var globalAssociateId
var globalFinalPrice 


// for connecting to local database
//see link for basics on mariadb
//https://mariadb.com/kb/en/library/connector-nodejs-promise-api/
//see link for basics for connecting mariadb and node.js
//https://mariadb.com/kb/en/library/getting-started-with-the-nodejs-connector/
//this username and password were arbitrary. create whatever names you like after
//logging into database instance as root. 
//mariadb server must be installed and running on your pc (this is why localhost is specified)
const pool = mariadb.createPool({
  //host: '127.0.0.1',
  host: 'localhost', 
  user:'team', 
  password: 'password',
  connectionLimit: 5, //specifies the number of connections to the database at any given time
                        // if conn.end() is run after each connection, the database will stop accepting requests
  database: '3b' //specify database name explicitly so sql command below works
});

// for connecting to legacy database
var connection = mysql.createConnection({
  host: 'er7lx9km02rjyf3n.cbetxkdyhwsb.us-east-1.rds.amazonaws.com',
  port: '3306',
  database: 'b25oudnru9u3blk4',
  user: 'rs0czd6o8w8e8r3j',
  password: 'w1ffboir25orrcs4',
});

// display message related to legacy database connection
connection.connect(function(err){
  if(err){
    console.error('Database connection failed: ' + err.stack);
    return;
  }
  console.log('Connected to database.');
});

// global variable tables holds value so it may be rendered on root of server
var tables;
connection.query('SHOW TABLES;', function (error, results, fields) {
  if (error) throw error;
  //console.log('Output of statement is: \n', results);
  tables = JSON.stringify(results);
});

//get values of from legacy database and place them in global variable customers
var customers;
connection.query('SELECT * from customers', function (error, results, fields) {
  if (error) throw error;
  //console.log('Output of statement is: \n', results);
  customers = JSON.stringify(results);
});

// end connection to legacy database
connection.end();

// homepage of server. this was setup as a demonstration of the contents of the legacy database
/* GET home page. */
router.get('/', function(req, res, next) {
 
  res.render('index', { title: 'Express', rows: tables,  rows2: customers});
  //res.send('we have connected the front-end and the back-end');    //from testAPI
  //function defined below is called here when page is accessed

  //somehow get values from frontend and pass them to build database query as follows:
  var test = "here is a test"

  queryDatabase(test, "insert");

});

//Router.get is getting information back from the external PO processing system
router.get('/externalPO', function(req, res, next) {

  //Axios call sends the information in the data field to the external PO processing system
  axios({
    method: 'post',
    url: 'http://blitz.cs.niu.edu/PurchaseOrder/',
    data: {
        //order:"xyz-547995-ba",
        //associate:"RE-676732",
        //custid:"21",
        //amount:"7654.32",

        order: globalOrderNum,
        associate: globalAssociateId,
        custid: globalCustomerId,
        amount :globalFinalPrice
    }
})
  .then(function (response) {
    console.log(response);
    res.send(response.data);
  })
  .catch(function (error) {
    console.log(error);
  });

});

// place contents of legacy database's customers table on this route
router.get('/passJSON', function(req, res, next) {
  res.send(customers);
});

// if no value needs to be passed into the database call, simply use router.get
//note use of async function here. this is so "await" can be used to block function
  // from completing until the database has responded with the results of the query.
// note the use of the second value passed to "queryDatabase". this will indicate which condition below
  // should be executed
router.get('/associates', async function (req, res, next) {
  //const associates = await queryDatabase("I%", "select");
  const associates = await queryDatabase("doesntMatter", "sales");
  console.log(associates);
  res.send(associates);
})


// quotes route hosts the information from the quotes database on a backend route
router.get('/quotes', async function (req, res, next) {
  //const associates = await queryDatabase("I%", "select");
  const associates = await queryDatabase("doesntMatter", "quotes");
  console.log(associates);
  res.send(associates);
})

// this route hosts only finalized quotes
router.get('/finalizedQuotes', async function (req, res, next) {
  //const associates = await queryDatabase("I%", "select");
  const finalized = await queryDatabase("doesntMatter", "finalizedQuotes");
  console.log(finalized);
  res.send(finalized);
})

/*
router.get('/finalPrice', async function (req, res, next) {
  const finalPrice = await queryDatabase(this.state.quoteId, "getFinalPrice");
  //const gettingId = await queryDatabase("doesntMatter", "getQuoteId") //JEFF GET QUOTE ID
  res.send(finalPrice);
  //res.send(gettingId)
})
*/

// lineiems hots the  information from the lineitems database on the backend
router.get('/lineitems', async function (req, res, next) {
  const lineitems = await queryDatabase("doesntMatter","items");
  console.log(lineitems);
  res.send(lineitems);
})

// the post route here receives user input from the frontend and repackages it into a format
  // acceptable for use in database queries containing placeholders.
// req.body contains the data that has been sent by the frontend. the if statements here determine
  // which type of request was made by looking for a unique value in the body of the request.
// note, the function that is executed at this route is asynchronous because sometimes a response
  // must be sent back to the frontend, so await must be used on the response from queryDatabase()
router.post('/post', async function(req, res, next) {
  console.log('!!!got a post request!!!');

  //body is where the json data is
  console.log(req.body);

  if (req.body.customerName != null) {
    //customerName is a key written into the json data on the frontend
    console.log(req.body.customerName);
    queryDatabase(req.body.customerName, "insert");
  } if (req.body.price != null) {
    //stores the packed data from frontend in an array and calls a function queryDatabase function where we pass array and insertQuote as type
    console.log("req.body.price: ", req.body.price);
    let array = [req.body.quoteID, req.body.itemNumber, req.body.description, req.body.price];
    queryDatabase(array, "insertQuote");
  }else if (req.body.associateName != null) {
    console.log(req.body.associateName);
    queryDatabase(req.body.associateName, "insert");
  } else if (req.body.quoteNum != null) {
    console.log(req.body.quoteNum);
    queryDatabase(req.body.quoteNum, "insert");
  }  else if (req.body.updateQuote != null) {
    //stores the packed data from frontend in an array and calls a function queryDatabase function where we pass array and updateQuotes as type
    console.log("req.body.quoteID: ", req.body.quoteID);
    let array = [req.body.updatedDescription, req.body.updatedPrice, req.body.quoteID, req.body.itemNumber];
    queryDatabase(array,"updateQuotes");
  }  else if (req.body.searchField != null) {
    console.log("searchField: ", req.body.searchField);
    let array = [req.body.searchField, req.body.searchQuery];
    const test = await queryDatabase(array, "searchQuotes");
    //console.log(test);
    res.send(test);
  } else if (req.body.finalDiscount != null) {
    console.log("finalDiscount: ", req.body.finalDiscount); //Console logging the final discount entered on the managers page
    let array = [req.body.finalDiscount,req.body.quoteId]; //Building an array with the quoteID and the finalDiscount
    queryDatabase(array,"insertDiscount"); //Calling the query database function and passing the array that was just built with type insertDiscount
    console.log("quoteId: ",req.body.quoteId); //Console logging to check the quoteId
    queryDatabase(req.body.quoteId,"getFinalPrice");//Calling the queryDatabase function to pass quoteId with type getFinalPrice
    //queryDatabase(req.body.finalDiscount,"insertDiscount");
    //console.log(test);
   /*else if(req.body.quoteId != null){
    //JEFFS GET QUOTE ID
    console.log("quoteId: ",req.body.quoteId)
    queryDatabase(req.body.quoteId,"getFinalPrice")
  } */ 
  //This code is using the quoteId to make a database query to retrieve necessary information to pass to the PO processing system
  }else if(req.body.sendPO != null){ 
  console.log("sendPO is accessing the backend and about to make queries"); //console logging to know we made it in here
  console.log("THE QUOTE ID HERE IS: ",req.body.quoteId); //console logging the quoteId that is being passed
  queryDatabase(req.body.quoteId,"sendPO"); //Passing quote it to queryDatabase with type sendPO

  }else if (req.body.salesAdd != null) {
    console.log("StreetAddress: ", req.body.StreetAddress);
    let array = [
      req.body.FirstName, 
      req.body.LastName,
      req.body.UserName,
      req.body.Password,
      "sales",
      req.body.StreetAddress,
      req.body.City,
      req.body.State,
      req.body.Zip,
      req.body.Email,
      0.0,
    ];
    const test = await queryDatabase(array, "addSales");
    //console.log(test);
    res.send(test);
  } else if (req.body.showEdit != null) {
    console.log("entering update associates post");
    let array = [
      req.body.associateId,
      req.body.FirstName, 
      req.body.LastName,
      req.body.UserName,
      req.body.Password,
      req.body.AccumulatedCommission,
      req.body.StreetAddress,
      req.body.City,
      req.body.State,
      req.body.Zip,
      req.body.Email,
    ]

    const res = await queryDatabase(array, "updateSales");
  } else if (req.body.delete != null) {
    console.log("associateId to delete: ", req.body.associateId);

    const test = await queryDatabase(req.body.associateId, "deleteSales");
    //response from database
    console.log(test);
    res.send(test);

  } else if (req.body.deleteQuote !=null ) {
    //stores the packed data from frontend in an array and calls a function queryDatabase function where we pass array and deleteQuotes as type
    console.log("quoteId:",req.body.quoteId);

    let array=[req.body.quoteId, req.body.itemNumber];

    queryDatabase(array,"deleteQuotes");

  } else if(req.body.searchQueryDiscount != null){ 
    console.log("Search Field: ",req.body.searchFieldDiscount,"Search Query: ",req.body.searchQueryDiscount);
    console.log("ENTERED INTO POST SEARCHQUERYDISCOUNT ELSE IF")
    let array = [req.body.searchFieldDiscount,req.body.searchQueryDiscount, req.body.quoteId]
    console.log("array for salesDiscount before function call: ", array)
    await queryDatabase(array,"salesDiscount")
} else {
  // if no identifying field was found in the request, drop out here
    console.log ("!!!error: no valid fields were found in the request body!!!")
  };

});


// a connection is made inside this function and is closed inside it as well
// input contains the data to be used in the database queries, while type differentiates
  // which type of query should be run
async function queryDatabase(input, type) {
  let conn;
  try {
  conn = await pool.getConnection();

  console.log("connected ! connection id is " + conn.threadId);
  //const rows = await conn.query("SELECT 1 as val");
  //console.log(rows); //[ {val: 1}, meta: ... ]
  //const res = await conn.query("INSERT INTO myTable value (?, ?)", [4, "ZZZZ"]);
  //console.log(res); // { affectedRows: 1, insertId: 1, warningStatus: 0 }
  
  let res;

  // the values within the array are inserted sequentially into the placeholders(question marks) in the query
  // this helps prevent SQL injection
  if (type == "insert") {
    res = await conn.query("INSERT INTO myTable value (?, ?)", [7, input]);
  } else if (type == "insertQuote") {
    //run this query and insert the data into lineitems
    res =await conn.query("INSERT INTO lineitems VALUES (?, ?, ?, ?)", [input[0], input[1], input[2], input[3]]);
  } else if (type == "sales") {
    //res = await conn.query("SELECT * FROM ASSOCIATES WHERE FirstName LIKE ?", [test]);
    res = await conn.query("SELECT * FROM Associates WHERE Role='sales'");
  } else if (type == "searchQuotes") {
    //res = await conn.query("SELECT * FROM ASSOCIATES WHERE FirstName LIKE ?", [test]);
    console.log("entering searchQuotes if statement");
    console.log("input[0]: ", input[0]);
    console.log("input[1]: ", input[1]);
    
    //since first and last name were stored separately in the database, this allows both to be searched
      // for by concatenating a strings together into the larger query one would like to make. the same
      // is done for processing date, though this didn't quite work (a warning will be given by the database
      // when the query is run; type SHOW WARNINGS to try to figure this out). template literals allow
      // the concatenated expanded query to be inserted into the statement to be run
    let field;

    if (input[0] == "Name") {
      field = "LastName='" + input[1] + "' OR FirstName"
    } else if (input[0] == "ProcessingDate") {
      console.log("you've entered the processing date condition in the queryDatabase function");
      var temp = input[1].split("-");
      console.log("split input: ", temp);
      //tack "'OR ProcessingDate" to both complete single quote query and not have to change syntax in
      //query below to remove equal sign after ${field} 
      field = "ProcessingDate >= '" + temp[0] + "' AND ProcessingDate <= '" + temp[1] + "' OR ProcessingDate"
      console.log("contents of field: ", field)
      input[1] = temp[1];
      console.log("new contents of input[1]", input[1])
      
    } else {
      field = input[0];
    }
    
    //res = await conn.query(`SELECT * FROM Quotes WHERE ${field}=?`, [input[1]]);
    
    res = await conn.query(`SELECT quotes.Status, quotes.ProcessingDate,
                            associates.FirstName, associates.LastName,
                            quotes.CustomerId 
                            FROM quotes INNER JOIN associates ON
                            quotes.AssociateId = associates.Id
                            WHERE ${field}=?`, [input[1]]);

  } else if (type == "quotes") {
    //res = await conn.query("SELECT * FROM ASSOCIATES WHERE FirstName LIKE ?", [test]);
    res = await conn.query("SELECT * FROM Quotes");
  } else if (type == "finalizedQuotes") {
    console.log("entering finalizedQuotes condition in queryDatabase function")
    res = await conn.query("SELECT * FROM Quotes WHERE Status='finalized'");
    //res = await conn.query("SELECT quotes. FROM Quotes WHERE Status='finalized'");
  } else if (type == "getFinalPrice") {
    //JEFF'S QUERY!!
    //res = await conn.query("SELECT * FROM lineitems WHERE QuoteId = 2");
    //console.log("res from Jeff's query: ", res);
    
    console.log("HELLO HELLO HELLO IS THERE ANYBODY OUT THERE") //Making sure we made it in here

    //this works to do all the math to determine the final amount by subtracting final discount from the price from the subtotal
    // this gets the result from the database and accessing it by stringifying and parsing the response,
    // then indexing into it
    pricei = await conn.query("SELECT Subtotal FROM quotes WHERE Id  = ?",[input]);
    //console.log("Pricei:",pricei)
    priceii = JSON.stringify(pricei);
    //console.log("Priceii",priceii)
    priceiii = JSON.parse(priceii);
    var x = parseFloat(priceiii[0]["Subtotal"]);
    //console.log("priceiii[0]['PriceBeforeDiscount']: ", priceiii[0]["PriceBeforeDiscount"])
    console.log("The Subtotal is: ", x);


    discounti = await conn.query("SELECT FinalDiscount FROM quotes WHERE Id = ?",[input]);
    //console.log("discounti",discounti)
    discountii = JSON.stringify(discounti);
    //console.log("discountii",discountii)
    discountiii = JSON.parse(discountii);
    var y = parseFloat(discountiii[0]["FinalDiscount"]);
    //console.log("discountiii[0]['FinalDiscount']: ",discountiii[0]["FinalDiscount"])
    console.log("The final discount is: ", y);


    var z = (x-y); //Storing the final price in Z
    console.log("THE FINAL PRICE IS",z);


    await conn.query("UPDATE quotes SET FinalPrice = ? WHERE Id = ?",[z,[input]]); //Updating the final price in the database

    res = [{
      "finalAmount": z,
      "id:":input,
    }];

    console.log("res: ", res);

  } else if (type == "insertDiscount") {
    //JEFF'S QUERY
    //res = await conn.query("INSERT INTO quotes (Status,PriceBeforeDiscount,DiscountPercentage,DiscountAmount,Subtotal,FinalDiscount,FinalPrice,ProcessingDate,AssociateId) VALUES (?,?,?,?,?,?,?,?,?)",["finalized",100,2,2,100,input,21,"2020-01-08 15:15:34",2]);
    res = await conn.query("UPDATE quotes SET FinalDiscount = ? WHERE Id = ?", [input[0],input[1]]); //Updating the finalDiscount entered on managers page
  }else if(type == "sendPO"){ 
    console.log("YOU MADE IT INTO SENDPO!");

    //The code below is used to get the information needed ready to be sent as a json object to the PO processing system

    var getOrderNum = await conn.query("SELECT Id FROM quotes WHERE Id = ?",[input]);
    var getAssociateId = await conn.query("SELECT AssociateId FROM quotes WHERE Id = ?",[input]);
    var getFinalPrice = await conn.query("SELECT FinalPrice FROM quotes WHERE Id = ?",[input]);
    var getCustomerId = await conn.query("SELECT CustomerId FROM quotes where Id = ?",[input]);

    var jsonOrderNum = JSON.stringify(getOrderNum);
    var jsonAssociateId = JSON.stringify(getAssociateId);
    var jsonFinalPrice = JSON.stringify(getFinalPrice);
    var jsonCustomerId = JSON.stringify(getCustomerId);

    var parseOrderNum = JSON.parse(jsonOrderNum);
    var parseAssociateId = JSON.parse(jsonAssociateId);
    var parseFinalPrice = JSON.parse(jsonFinalPrice);
    var parseCustomerId = JSON.parse(jsonCustomerId);

    var sendOrderNum = parseInt(parseOrderNum[0]["Id"]);
    var sendAssociateId = parseInt(parseAssociateId[0]["AssociateId"]); 
    var sendFinalPrice = parseFloat(parseFinalPrice[0]["FinalPrice"]);
    var sendCustomerId = parseInt(parseCustomerId[0]["CustomerId"]);

    //Using the global variables here
    globalOrderNum = sendOrderNum;
    globalAssociateId = sendAssociateId;
    globalFinalPrice = sendFinalPrice;
    globalCustomerId = sendCustomerId;

    //Console logging the results to check
    console.log("FINAL PO ORDER NUMBER: ",sendOrderNum);
    console.log("FINAL PO ASSOCIATE ID: ",sendAssociateId);
    console.log("FINAL PO GET FIANL PRICE: ",sendFinalPrice);
    console.log("FINAL PO CUSTOMER ID: ",sendCustomerId); 

  
  }else if (type == "items") {
    //runs this query to display the entire lineitems table in frontend
    res = await conn.query("SELECT * FROM lineitems");
  } else if ( type == "updateQuotes") {
    //updates the lineitems table with description and price of the quote entered by the user
    res = await conn.query("UPDATE lineitems SET ItemDescription= ? , ItemPrice= ? WHERE QuoteId = ? AND ItemNumber= ?", [input[0], input[1], input[2], input[3]]);
  }
  else if (type == "addSales") {
    res = await conn.query(
      "INSERT INTO associates(FirstName, LastName, Username, Password, Role, StreetAddress," + 
      " City, State, Zip, Email, AccumulatedCommission) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [
      input[0], input[1], input[2], input[3], input[4], input[5], input[6], input[7], input[8],
      input[9], input[10], input[11]
    ]);
  }else if(type == "quoteId"){
    res = await conn.query("SELECT Id FROM quotes WHERE Id = 4") //JEFFS GET QUOTE ID

  }else if (type == "updateSales") {

    res = await conn.query(
    "UPDATE associates SET FirstName = ?, LastName = ?, UserName = ?, " +
    "Password = ?, AccumulatedCommission = ?, StreetAddress = ?, City = ?, State = ?, Zip = ?, " +
    "Email = ? WHERE Id=?;", [input[1], input[2], input[3], input[4],
      input[5], input[6], input[7], input[8], input[9], input[10], input[0]
    ]);
    
  }
  else if (type == "deleteSales") {
    console.log("input variable received in the deleteSales condition", input);
    res = await conn.query("DELETE FROM associates WHERE Id=?", [input]);

  } else if ( type == "deleteQuotes") {
    //deletes the record by running this sql query
    console.log("made it into delete Quotes");
    console.log("input", input);
    res = await conn.query("DELETE FROM lineitems WHERE QuoteId=? AND ItemNumber=?", [input[0],input[1]]);
  } else if(type == "salesDiscount"){
    // a much improved version of database math is done here, though there is redundancy involved in the
    // database. see the if/else statement where the if condition checks for equality with "dollarAmount"
    console.log("MADE IT INTO QUERY DATABASE salesDiscount");
    console.log("contents of input array in salesDiscount condition of queryDatabase function", input)
    console.log("About to this discount into the database: ",input[1]);
    //res = await conn.query("UPDATE quotes SET ")
      var x = await conn.query("SELECT SUM(ItemPrice) from lineitems WHERE quoteId=?", [input[2]]);
      console.log("value in x: ", x);
      var y = JSON.stringify(x);
      //console.log("Priceii",priceii)
      var z = JSON.parse(y);
      var a = parseFloat(z[0]["SUM(ItemPrice)"]);
      await conn.query("UPDATE quotes SET PriceBeforeDiscount=? WHERE Id=?", [a, input[2]]);

      // by hardcoding zero into the statement for DiscountPercentage or DiscountAmount, only one type of discount
      // can be used
      if(input[0] == "dollarAmount") 
      {
         res = await conn.query("UPDATE quotes SET DiscountAmount =?, DiscountPercentage = 0 WHERE Id =?",[input[1], input[2]]); //Need dynamic Id (DOLLAR AMOUNT)
         let res2 = await conn.query("UPDATE quotes SET Subtotal = (PriceBeforeDiscount - DiscountAmount) WHERE Id=?", [input[2]]);
         console.log("res2 for dollarAmount condition in salesDiscount", res2);    
      }
      else
      {
        res = await conn.query("UPDATE quotes SET DiscountPercentage = ?, DiscountAmount = 0 WHERE Id = ?",[input[1], input[2]]); //Need dynamic Id (PERCENTAGE AMOUNT)
        let res2 = await conn.query("UPDATE quotes SET Subtotal = (PriceBeforeDiscount - (PriceBeforeDiscount * DiscountPercentage/100)) WHERE Id=?", [input[2]]);
        console.log("res2 for unnamed else condition (percentageAmount) in salesDiscount", res2);
      }

        console.log(res);
  } else {
    // if no type or an incorrect type was provided, drop out here
    console.log("!!!error: incorrect type provided!!!");
  }
  
  // end the database connection here
  conn.end();

  //put the database response in an appropriate format and return it
  let value = JSON.stringify(res);
  console.log("here is the stringified database query result: ", value);
  return value;

  } catch (err) {
  throw err;
  }

}
module.exports = router;
