// Unused at the moment

/*
var express = require('express');
var router = express.Router();

router.get('/', function(req, res, next) {
    res.send('WE HAVE CONNECTED FRONT-END AND BACK-END');
});

module.exports = router;
//*/